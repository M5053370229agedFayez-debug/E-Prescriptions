using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class PurchasesView : UserControl
    {
        public PurchasesView() { InitializeComponent(); }
    }
}
