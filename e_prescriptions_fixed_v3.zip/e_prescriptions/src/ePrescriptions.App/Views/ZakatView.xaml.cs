using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class ZakatView : UserControl
    {
        public ZakatView() { InitializeComponent(); }
    }
}
