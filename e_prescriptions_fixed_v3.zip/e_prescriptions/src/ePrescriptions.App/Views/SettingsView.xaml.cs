using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class SettingsView : UserControl
    {
        public SettingsView() { InitializeComponent(); }
    }
}
