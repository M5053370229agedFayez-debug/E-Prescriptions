using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class ReportsView : UserControl
    {
        public ReportsView() { InitializeComponent(); }
    }
}
