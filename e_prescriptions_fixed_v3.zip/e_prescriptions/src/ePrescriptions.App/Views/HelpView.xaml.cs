using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class HelpView : UserControl
    {
        public HelpView() { InitializeComponent(); }
    }
}
