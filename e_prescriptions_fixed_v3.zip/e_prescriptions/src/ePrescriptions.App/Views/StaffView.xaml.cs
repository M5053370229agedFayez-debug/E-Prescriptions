using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class StaffView : UserControl
    {
        public StaffView() { InitializeComponent(); }
    }
}
