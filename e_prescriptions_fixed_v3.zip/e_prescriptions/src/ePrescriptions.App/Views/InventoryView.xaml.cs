using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class InventoryView : UserControl
    {
        public InventoryView() { InitializeComponent(); }
    }
}
