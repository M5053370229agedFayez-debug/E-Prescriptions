using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class FinanceView : UserControl
    {
        public FinanceView() { InitializeComponent(); }
    }
}
