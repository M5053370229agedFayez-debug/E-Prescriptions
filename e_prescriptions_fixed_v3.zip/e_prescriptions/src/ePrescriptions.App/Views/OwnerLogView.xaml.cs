using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class OwnerLogView : UserControl
    {
        public OwnerLogView() { InitializeComponent(); }
    }
}
