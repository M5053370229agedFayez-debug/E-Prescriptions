using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class SalesView : UserControl
    {
        public SalesView()
        {
            InitializeComponent();
        }
    }
}
