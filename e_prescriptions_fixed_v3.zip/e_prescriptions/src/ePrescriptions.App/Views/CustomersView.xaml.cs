using System.Windows.Controls;

namespace ePrescriptions.App.Views
{
    public partial class CustomersView : UserControl
    {
        public CustomersView() { InitializeComponent(); }
    }
}
