using System;
using System.Globalization;
using System.Threading;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using ePrescriptions.App.Services;
using ePrescriptions.App.ViewModels;
using ePrescriptions.Core.Helpers;
using ePrescriptions.Data;
using ePrescriptions.Data.Repositories;

namespace ePrescriptions.App
{
    public partial class App : Application
    {
        private SingleInstanceMutex? _singleInstanceMutex;
        private IServiceProvider? _serviceProvider;

        public static IServiceProvider ServiceProvider => ((App)Current)._serviceProvider!;

        protected override void OnStartup(StartupEventArgs e)
        {
            // منع إغلاق البرنامج تلقائياً عند غلق نافذة الدخول قبل ظهور النافذة الرئيسية
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            // 1) قفل نسخة واحدة بـ Mutex
            _singleInstanceMutex = new SingleInstanceMutex();
            if (!_singleInstanceMutex.IsSingleInstance)
            {
                MessageBox.Show(
                    "برنامج e_prescriptions يعمل بالفعل على هذا الجهاز في الخلفية.",
                    "تنبيه - نسخة مكررة",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                Shutdown();
                return;
            }

            // 2) معالجة الأخطاء غير المتوقعة وتسجيلها في ملف AppData
            SetupGlobalExceptionHandling();

            // 3) ضبط الثقافة: مصر (تقويم ميلادي) حتى لا تُكتب تواريخ قاعدة البيانات بالسنة الهجرية، مع أرقام لاتينية
            var culture = new CultureInfo("ar-EG", false);
            culture.NumberFormat.DigitSubstitution = DigitShapes.None;
            Thread.CurrentThread.CurrentCulture = culture;
            Thread.CurrentThread.CurrentUICulture = culture;

            base.OnStartup(e);

            // 4) إعداد حقن التبعيات (DI)
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            _serviceProvider = serviceCollection.BuildServiceProvider();

            // 5) تهيئة قاعدة بيانات SQLite وتطبيق الـ Migrations والبيانات التجريبية
            try
            {
                var dbContext = _serviceProvider.GetRequiredService<DatabaseContext>();
                dbContext.InitializeAndMigrate(seedData: true);
                Logger.LogInfo("تم تشغيل التطبيق بنجاح وتهيئة قاعدة البيانات.", "App.OnStartup");
            }
            catch (Exception ex)
            {
                Logger.LogException(ex, "App.InitializeDatabase");
                MessageBox.Show(
                    $"حدث خطأ أثناء تهيئة قاعدة البيانات:\n{ex.Message}\nيرجى مراجعة سجل الأخطاء في AppData.",
                    "خطأ فادح في قاعدة البيانات",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }

            // 6) تسجيل الدخول الأولي لحماية نقطة البيع
            var sessionService = _serviceProvider.GetRequiredService<IUserSessionService>();
            var loginVm = _serviceProvider.GetRequiredService<LoginViewModel>();
            var loginWin = new Views.LoginWindow(loginVm);
            if (loginWin.ShowDialog() != true)
            {
                Shutdown();
                return;
            }

            // 7) تعيين الشاشة الافتراضية عند الفتح وهي المبيعات (SalesViewModel)
            var navService = _serviceProvider.GetRequiredService<INavigationService>();
            navService.NavigateTo<SalesViewModel>();

            var mainWindow = _serviceProvider.GetRequiredService<MainWindow>();
            MainWindow = mainWindow;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            mainWindow.Show();
        }

        private static void ConfigureServices(IServiceCollection services)
        {
            // Database
            services.AddSingleton<DatabaseContext>();

            // Repositories
            services.AddSingleton<ItemRepository>();
            services.AddSingleton<InvoiceRepository>();
            services.AddSingleton<CustomerRepository>();
            services.AddSingleton<UserRepository>();
            services.AddSingleton<ShiftRepository>();
            services.AddSingleton<SettingsRepository>();
            services.AddSingleton<PurchaseRepository>();
            services.AddSingleton<SupplierRepository>();
            services.AddSingleton<FinanceRepository>();
            services.AddSingleton<ReportRepository>();
            services.AddSingleton<OwnerAuditLogRepository>();

            // Services & Export
            services.AddSingleton<IUserSessionService, UserSessionService>();
            services.AddSingleton<IBarcodeLabelService, BarcodeLabelService>();
            services.AddSingleton<IExcelExportService, ExcelExportService>();
            services.AddSingleton<IBackupService, BackupService>();
            services.AddSingleton<IPdfReportService, PdfReportService>();

            // Navigation
            services.AddSingleton<INavigationService, NavigationService>();

            // ViewModels
            services.AddSingleton<MainViewModel>();
            services.AddTransient<LoginViewModel>();
            services.AddTransient<SalesViewModel>();
            services.AddTransient<InventoryViewModel>();
            services.AddTransient<PurchasesViewModel>();
            services.AddTransient<CustomersViewModel>();
            services.AddTransient<FinanceViewModel>();
            services.AddTransient<StaffViewModel>();
            services.AddTransient<ZakatViewModel>();
            services.AddTransient<ReportsViewModel>();
            services.AddTransient<SettingsViewModel>();
            services.AddTransient<HelpViewModel>();
            services.AddTransient<OwnerLogViewModel>();

            // Views & Main Window
            services.AddSingleton<MainWindow>();
        }

        private void SetupGlobalExceptionHandling()
        {
            DispatcherUnhandledException += (s, args) =>
            {
                Logger.LogException(args.Exception, "DispatcherUnhandledException");
                MessageBox.Show(
                    $"حدث خطأ أثناء تنفيذ العملية:\n{args.Exception.Message}\nتم تسجيل التفاصيل في السجل دون إغلاق البرنامج.",
                    "تنبيه - خطأ غير معالج",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                args.Handled = true; // منع إغلاق البرنامج فجأة
            };

            AppDomain.CurrentDomain.UnhandledException += (s, args) =>
            {
                if (args.ExceptionObject is Exception ex)
                {
                    Logger.LogException(ex, "AppDomain.UnhandledException");
                }
            };
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _singleInstanceMutex?.Dispose();
            base.OnExit(e);
        }
    }
}
