using System;
using System.Collections.ObjectModel;
using System.Linq;
using CommunityToolkit.Mvvm.Input;
using ePrescriptions.Data.Repositories;

namespace ePrescriptions.App.ViewModels
{
    /// <summary>
    /// عرض سطر واحد من سجل نشاط صاحب الصيدلية بشكل مقروء
    /// </summary>
    public class OwnerLogEntryDisplay
    {
        public string FormattedDate { get; set; } = string.Empty;
        public string EntityLabel { get; set; } = string.Empty;
        public string FieldName { get; set; } = string.Empty;
        public string OldValue { get; set; } = string.Empty;
        public string NewValue { get; set; } = string.Empty;
    }

    /// <summary>
    /// شاشة سجل نشاط صاحب الصيدلية. يجب ألا تُضاف إلى أي DataTemplate أو زر تنقل يظهر لغير دور Owner.
    /// الحماية الحقيقية الإضافية تكمن في أن INavigationService لا يستدعي هذه الشاشة أصلاً إلا من زر
    /// محمي بـ IsOwner في MainViewModel، وهذا الزر غير مرئي لأي دور آخر.
    /// </summary>
    public class OwnerLogViewModel : ViewModelBase
    {
        private readonly OwnerAuditLogRepository _ownerAuditLogRepository;

        public ObservableCollection<OwnerLogEntryDisplay> Entries { get; } = new();

        private string _statusMessage = string.Empty;
        public string StatusMessage
        {
            get => _statusMessage;
            set => SetProperty(ref _statusMessage, value);
        }

        public IRelayCommand RefreshCommand { get; }

        public OwnerLogViewModel(OwnerAuditLogRepository ownerAuditLogRepository)
        {
            Title = "سجل نشاطي (مرئي لك فقط)";
            _ownerAuditLogRepository = ownerAuditLogRepository;

            RefreshCommand = new RelayCommand(LoadData);
            LoadData();
        }

        public void LoadData()
        {
            Entries.Clear();
            var logs = _ownerAuditLogRepository.GetRecent(300);

            foreach (var log in logs.OrderByDescending(l => l.ChangedAt))
            {
                Entries.Add(new OwnerLogEntryDisplay
                {
                    FormattedDate = log.ChangedAt.ToString("yyyy-MM-dd HH:mm"),
                    EntityLabel = log.EntityLabel,
                    FieldName = log.FieldName,
                    OldValue = log.OldValue ?? "-",
                    NewValue = log.NewValue ?? "-"
                });
            }

            StatusMessage = Entries.Count == 0
                ? "لا توجد تعديلات مسجّلة بعد."
                : $"عدد التعديلات المسجّلة: {Entries.Count}";
        }
    }
}
