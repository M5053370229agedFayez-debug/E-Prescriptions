using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Media;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using ePrescriptions.Core.Financial;
using ePrescriptions.Core.Helpers;
using ePrescriptions.Data.Repositories;
using ePrescriptions.Domain.Entities;
using ePrescriptions.Domain.Enums;

namespace ePrescriptions.App.ViewModels
{
    public class SalesViewModel : ViewModelBase
    {
        private readonly ItemRepository _itemRepository;
        private readonly InvoiceRepository _invoiceRepository;
        private readonly CustomerRepository _customerRepository;
        private readonly SettingsRepository _settingsRepository;
        private readonly Services.IPdfReportService? _pdfReportService;
        private readonly Services.IUserSessionService? _sessionService;

        // المستخدم والوردية الحاليان من جلسة الدخول (القيم الافتراضية للتوافق عند غياب الجلسة)
        private int CurrentUserId => _sessionService?.CurrentUser?.Id ?? 1;
        private string CurrentUserName => _sessionService?.CurrentUser?.FullName ?? "ماجد القبانى";
        private int CurrentShiftId => _sessionService?.CurrentShift?.Id ?? 1;

        // رأس الفاتورة
        private string _invoiceNumber = string.Empty;
        public string InvoiceNumber
        {
            get => _invoiceNumber;
            set => SetProperty(ref _invoiceNumber, value);
        }

        private InvoiceType _currentInvoiceType = InvoiceType.Sales;
        public InvoiceType CurrentInvoiceType
        {
            get => _currentInvoiceType;
            set
            {
                if (SetProperty(ref _currentInvoiceType, value))
                {
                    OnPropertyChanged(nameof(IsReturnMode));
                    OnPropertyChanged(nameof(InvoiceTypeTitle));
                }
            }
        }

        public bool IsReturnMode => CurrentInvoiceType == InvoiceType.Return;
        public string InvoiceTypeTitle => IsReturnMode ? "فاتورة مرتجع مبيعات" : "فاتورة مبيعات جديدة";

        // بيانات العميل والوصفة
        private string _customerName = "عميل نقدي";
        public string CustomerName
        {
            get => _customerName;
            set => SetProperty(ref _customerName, value);
        }

        private string _customerPhone = string.Empty;
        public string CustomerPhone
        {
            get => _customerPhone;
            set => SetProperty(ref _customerPhone, value);
        }

        private PriceCategory _selectedPriceCategory = PriceCategory.Retail;
        public PriceCategory SelectedPriceCategory
        {
            get => _selectedPriceCategory;
            set
            {
                if (SetProperty(ref _selectedPriceCategory, value))
                {
                    // تحديث الأسعار لجميع البنود الحالية
                    foreach (var item in CartItems)
                    {
                        item.UpdatePriceBasedOnUnit();
                    }
                    RecalculateTotals();
                }
            }
        }

        private PaymentMethod _selectedPaymentMethod = PaymentMethod.Cash;
        public PaymentMethod SelectedPaymentMethod
        {
            get => _selectedPaymentMethod;
            set
            {
                if (SetProperty(ref _selectedPaymentMethod, value))
                {
                    if (value == PaymentMethod.Cash || value == PaymentMethod.Network)
                    {
                        PaidRiyals = TotalNetRiyals;
                    }
                    else if (value == PaymentMethod.OnAccount)
                    {
                        PaidRiyals = 0;
                    }
                    RecalculateTotals();
                }
            }
        }

        private string _prescriptionNumber = string.Empty;
        public string PrescriptionNumber
        {
            get => _prescriptionNumber;
            set => SetProperty(ref _prescriptionNumber, value);
        }

        private string _doctorName = string.Empty;
        public string DoctorName
        {
            get => _doctorName;
            set => SetProperty(ref _doctorName, value);
        }

        // البحث اللحظي والباركود
        private string _searchQuery = string.Empty;
        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                if (SetProperty(ref _searchQuery, value))
                {
                    PerformSearch(value);
                }
            }
        }

        public ObservableCollection<Item> SearchResults { get; } = new();
        public ObservableCollection<Item> TopSellingItems { get; } = new();
        public ObservableCollection<SalesItemRow> CartItems { get; } = new();
        public ObservableCollection<Customer> CustomersList { get; } = new();

        // المجاميع بالقروش
        private long _subtotalPiastres;
        public long SubtotalPiastres
        {
            get => _subtotalPiastres;
            set => SetProperty(ref _subtotalPiastres, value);
        }

        private long _discountPiastres;
        public long DiscountPiastres
        {
            get => _discountPiastres;
            set => SetProperty(ref _discountPiastres, value);
        }

        private long _vatPiastres;
        public long VatPiastres
        {
            get => _vatPiastres;
            set => SetProperty(ref _vatPiastres, value);
        }

        private long _netTotalPiastres;
        public long NetTotalPiastres
        {
            get => _netTotalPiastres;
            set => SetProperty(ref _netTotalPiastres, value);
        }

        private decimal _paidRiyals;
        public decimal PaidRiyals
        {
            get => _paidRiyals;
            set
            {
                if (SetProperty(ref _paidRiyals, value))
                {
                    RecalculateTotals();
                }
            }
        }

        private long _remainingPiastres;
        public long RemainingPiastres
        {
            get => _remainingPiastres;
            set => SetProperty(ref _remainingPiastres, value);
        }

        // خواص العرض بالجنيه المصري (مع الحفاظ على الأسماء للتوافق الكامل)
        public decimal SubtotalRiyals => Money.FromPiastres(SubtotalPiastres).ToPounds();
        public decimal DiscountRiyals => Money.FromPiastres(DiscountPiastres).ToPounds();
        public decimal VatRiyals => Money.FromPiastres(VatPiastres).ToPounds();
        public decimal TotalNetRiyals => Money.FromPiastres(NetTotalPiastres).ToPounds();
        public decimal RemainingRiyals => Money.FromPiastres(RemainingPiastres).ToPounds();

        // مرادفات بالجنيه
        public decimal SubtotalPounds => SubtotalRiyals;
        public decimal VatPounds => VatRiyals;
        public decimal TotalNetPounds => TotalNetRiyals;
        public decimal RemainingPounds => RemainingRiyals;
        public decimal PaidPounds => PaidRiyals;

        // إشعارات الحالة
        private string _statusMessage = "جاهز لاستقبال عمليات البيع";
        public string StatusMessage
        {
            get => _statusMessage;
            set => SetProperty(ref _statusMessage, value);
        }

        private bool _isStatusSuccess = true;
        public bool IsStatusSuccess
        {
            get => _isStatusSuccess;
            set => SetProperty(ref _isStatusSuccess, value);
        }

        // الأوامر (F1..F10)
        public IRelayCommand NewInvoiceCommand { get; }
        public IRelayCommand SaveInvoiceCommand { get; }
        public IRelayCommand PrintInvoiceCommand { get; }
        public IRelayCommand PrintA4InvoicePdfCommand { get; }
        public IRelayCommand SuspendInvoiceCommand { get; }
        public IRelayCommand ToggleReturnModeCommand { get; }
        public IRelayCommand OpenCashDrawerCommand { get; }
        public IRelayCommand<SalesItemRow> RemoveItemCommand { get; }
        public IRelayCommand<Item> AddItemToCartCommand { get; }
        public IRelayCommand BarcodeEnterCommand { get; }

        public SalesViewModel(
            ItemRepository itemRepository,
            InvoiceRepository invoiceRepository,
            CustomerRepository customerRepository,
            SettingsRepository settingsRepository,
            Services.IPdfReportService? pdfReportService = null,
            Services.IUserSessionService? sessionService = null)
        {
            _sessionService = sessionService;
            Title = "نقطة البيع - المبيعات";
            _itemRepository = itemRepository;
            _invoiceRepository = invoiceRepository;
            _customerRepository = customerRepository;
            _settingsRepository = settingsRepository;
            _pdfReportService = pdfReportService;

            NewInvoiceCommand = new RelayCommand(StartNewInvoice);
            SaveInvoiceCommand = new RelayCommand(SaveCurrentInvoice);
            PrintInvoiceCommand = new RelayCommand(PrintCurrentInvoice);
            PrintA4InvoicePdfCommand = new RelayCommand(PrintA4InvoicePdf);
            SuspendInvoiceCommand = new RelayCommand(SuspendCurrentInvoice);
            ToggleReturnModeCommand = new RelayCommand(ToggleReturnMode);
            OpenCashDrawerCommand = new RelayCommand(OpenDrawer);
            RemoveItemCommand = new RelayCommand<SalesItemRow>(RemoveItem);
            AddItemToCartCommand = new RelayCommand<Item>(AddItem);
            BarcodeEnterCommand = new RelayCommand(HandleBarcodeEnter);

            LoadInitialData();
            StartNewInvoice();
        }

        private void LoadInitialData()
        {
            try
            {
                var topItems = _itemRepository.GetTopSellingItems(8);
                TopSellingItems.Clear();
                foreach (var itm in topItems) TopSellingItems.Add(itm);

                var customers = _customerRepository.GetAll();
                CustomersList.Clear();
                foreach (var c in customers) CustomersList.Add(c);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex, "SalesViewModel.LoadInitialData");
            }
        }

        public void StartNewInvoice()
        {
            InvoiceNumber = _invoiceRepository.GenerateNextInvoiceNumber(CurrentInvoiceType);
            CustomerName = "عميل نقدي";
            CustomerPhone = string.Empty;
            PrescriptionNumber = string.Empty;
            DoctorName = string.Empty;
            SelectedPaymentMethod = PaymentMethod.Cash;
            SelectedPriceCategory = PriceCategory.Retail;
            CartItems.Clear();
            SearchQuery = string.Empty;
            SearchResults.Clear();
            PaidRiyals = 0;
            RecalculateTotals();
            SetStatus("تم تجهيز فاتورة جديدة جاهزة للبيع", true);
        }

        private void PerformSearch(string query)
        {
            SearchResults.Clear();
            if (string.IsNullOrWhiteSpace(query) || query.Length < 2) return;

            try
            {
                var list = _itemRepository.Search(query, 15);
                foreach (var itm in list) SearchResults.Add(itm);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex, "SalesViewModel.PerformSearch");
            }
        }

        public void HandleBarcodeEnter()
        {
            string code = SearchQuery.Trim();
            if (string.IsNullOrEmpty(code)) return;

            var item = _itemRepository.GetByBarcodeOrCode(code);
            if (item != null)
            {
                AddItem(item);
                SearchQuery = string.Empty;
                SearchResults.Clear();
            }
            else
            {
                SetStatus($"لم يتم العثور على صنف بالباركود: {code}", false);
            }
        }

        public void AddItem(Item? item)
        {
            if (item == null) return;

            int defaultVat = 14;
            try
            {
                var s = _settingsRepository.GetSettings();
                defaultVat = s.DefaultVatPercent;
            }
            catch { }

            // التحقق مما إذا كان الصنف مضافاً مسبقاً بنفس الوحدة
            var existing = CartItems.FirstOrDefault(x => x.ItemId == item.Id && x.SelectedUnitLevel == UnitLevel.Box);
            if (existing != null)
            {
                existing.Quantity++;
            }
            else
            {
                var row = new SalesItemRow(item, SelectedPriceCategory, defaultVat);
                row.PropertyChanged += (s, e) => RecalculateTotals();
                CartItems.Add(row);
            }

            RecalculateTotals();
            SetStatus($"تمت إضافة: {item.NameAr}", true);
        }

        public void RemoveItem(SalesItemRow? row)
        {
            if (row != null && CartItems.Contains(row))
            {
                CartItems.Remove(row);
                RecalculateTotals();
                SetStatus($"تم حذف البند: {row.NameAr}", true);
            }
        }

        public void RecalculateTotals()
        {
            long sub = 0;
            long disc = 0;
            long vat = 0;
            long net = 0;

            foreach (var row in CartItems)
            {
                long gross = row.UnitPricePiastres * row.Quantity;
                sub += gross;
                disc += row.DiscountPiastres;
                vat += row.VatPiastres;
                net += row.TotalPiastres;
            }

            SubtotalPiastres = sub;
            DiscountPiastres = disc;
            VatPiastres = vat;
            NetTotalPiastres = net;

            if (SelectedPaymentMethod == PaymentMethod.Cash || SelectedPaymentMethod == PaymentMethod.Network)
            {
                PaidRiyals = TotalNetRiyals;
            }

            long paidPiastres = Money.FromPounds(PaidRiyals).Piastres;
            RemainingPiastres = Math.Max(0, NetTotalPiastres - paidPiastres);

            OnPropertyChanged(nameof(SubtotalRiyals));
            OnPropertyChanged(nameof(DiscountRiyals));
            OnPropertyChanged(nameof(VatRiyals));
            OnPropertyChanged(nameof(TotalNetRiyals));
            OnPropertyChanged(nameof(RemainingRiyals));

            OnPropertyChanged(nameof(SubtotalPounds));
            OnPropertyChanged(nameof(VatPounds));
            OnPropertyChanged(nameof(TotalNetPounds));
            OnPropertyChanged(nameof(RemainingPounds));
            OnPropertyChanged(nameof(PaidPounds));
        }

        public void SaveCurrentInvoice()
        {
            if (CartItems.Count == 0)
            {
                SetStatus("لا يمكن حفظ فاتورة فارغة! أضف أصنافاً أولاً.", false);
                return;
            }

            try
            {
                // ربط الفاتورة بعميل مسجل (مطلوب لتحديث رصيد العميل في البيع الآجل)
                string typedName = (CustomerName ?? string.Empty).Trim();
                var matchedCustomer = CustomersList.FirstOrDefault(c => c.Id > 1 &&
                    string.Equals(c.Name.Trim(), typedName, StringComparison.OrdinalIgnoreCase));

                if (SelectedPaymentMethod == PaymentMethod.OnAccount && matchedCustomer == null)
                {
                    SetStatus("البيع الآجل يتطلب اختيار عميل مسجل بنفس الاسم من قائمة العملاء.", false);
                    return;
                }

                var settings = _settingsRepository.GetSettings();
                DateTime now = DateTime.Now;

                // إنشاء رمز QR بسيط إن كان مفعلاً في الإعدادات
                string? qrText = null;
                if (settings.EnableQrCode)
                {
                    qrText = EgyptQrHelper.GenerateSimpleInvoiceQrText(
                        InvoiceNumber,
                        now,
                        TotalNetRiyals,
                        settings.TaxNumber,
                        settings.PharmacyNameAr
                    );
                }

                var invoice = new Invoice
                {
                    InvoiceNumber = InvoiceNumber,
                    Type = CurrentInvoiceType,
                    Date = now,
                    CustomerId = matchedCustomer?.Id,
                    CustomerName = CustomerName,
                    CustomerPhone = CustomerPhone,
                    PriceCategory = SelectedPriceCategory,
                    PaymentMethod = SelectedPaymentMethod,
                    PrescriptionNumber = PrescriptionNumber,
                    DoctorName = DoctorName,
                    UserId = CurrentUserId,
                    UserName = CurrentUserName,
                    ShiftId = CurrentShiftId,
                    SubtotalPiastres = SubtotalPiastres,
                    DiscountPiastres = DiscountPiastres,
                    VatPiastres = VatPiastres,
                    TotalPiastres = NetTotalPiastres,
                    PaidPiastres = Money.FromPounds(PaidRiyals).Piastres,
                    RemainingPiastres = RemainingPiastres,
                    QrCodeText = qrText
                };

                foreach (var row in CartItems)
                {
                    invoice.Items.Add(new InvoiceItem
                    {
                        ItemId = row.ItemId,
                        ItemCode = row.Code,
                        ItemNameAr = row.NameAr,
                        BatchNumber = row.BatchNumber,
                        ExpiryDate = row.ExpiryDate,
                        UnitLevel = row.SelectedUnitLevel,
                        QuantitySold = row.Quantity,
                        SmallestUnitsCount = row.SmallestUnitsToDeduct,
                        UnitPricePiastres = row.UnitPricePiastres,
                        DiscountPiastres = row.DiscountPiastres,
                        VatRatePercent = row.VatRatePercent,
                        VatPiastres = row.VatPiastres,
                        TotalPiastres = row.TotalPiastres
                    });
                }

                if (_invoiceRepository.SaveInvoice(invoice, out string err))
                {
                    SetStatus($"تم حفظ الفاتورة بنجاح: {invoice.InvoiceNumber}", true);
                    PlayConfirmSound();
                    StartNewInvoice();
                }
                else
                {
                    SetStatus($"فشل حفظ الفاتورة: {err}", false);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex, "SaveCurrentInvoice");
                SetStatus($"خطأ غير متوقع: {ex.Message}", false);
            }
        }

        public void PrintCurrentInvoice()
        {
            if (CartItems.Count == 0)
            {
                SetStatus("لا يمكن طباعة فاتورة فارغة!", false);
                return;
            }

            try
            {
                var settings = _settingsRepository.GetSettings();
                string? qrText = null;
                if (settings.EnableQrCode)
                {
                    qrText = EgyptQrHelper.GenerateSimpleInvoiceQrText(
                        InvoiceNumber,
                        DateTime.Now,
                        TotalNetRiyals,
                        settings.TaxNumber,
                        settings.PharmacyNameAr
                    );
                }

                var invoice = new Invoice
                {
                    InvoiceNumber = InvoiceNumber,
                    Date = DateTime.Now,
                    CustomerName = CustomerName,
                    CustomerPhone = CustomerPhone,
                    PaymentMethod = SelectedPaymentMethod,
                    SubtotalPiastres = SubtotalPiastres,
                    DiscountPiastres = DiscountPiastres,
                    VatPiastres = VatPiastres,
                    TotalPiastres = NetTotalPiastres,
                    PaidPiastres = Money.FromPounds(PaidRiyals).Piastres,
                    RemainingPiastres = RemainingPiastres,
                    QrCodeText = qrText
                };

                foreach (var row in CartItems)
                {
                    invoice.Items.Add(new InvoiceItem
                    {
                        ItemId = row.ItemId,
                        ItemCode = row.Code,
                        ItemNameAr = row.NameAr,
                        BatchNumber = row.BatchNumber,
                        ExpiryDate = row.ExpiryDate,
                        UnitLevel = row.SelectedUnitLevel,
                        QuantitySold = row.Quantity,
                        SmallestUnitsCount = row.SmallestUnitsToDeduct,
                        UnitPricePiastres = row.UnitPricePiastres,
                        DiscountPiastres = row.DiscountPiastres,
                        VatRatePercent = row.VatRatePercent,
                        VatPiastres = row.VatPiastres,
                        TotalPiastres = row.TotalPiastres
                    });
                }

                if (Services.ThermalReceiptPrinter.PrintReceipt(invoice, settings, out string err))
                {
                    SetStatus("تمت طباعة الإيصال الحراري بنجاح (F3)", true);
                }
                else
                {
                    SetStatus($"تعذر طباعة الإيصال: {err}", false);
                }
            }
            catch (Exception ex)
            {
                SetStatus($"خطأ في الطباعة: {ex.Message}", false);
            }
        }

        public void PrintA4InvoicePdf()
        {
            if (CartItems.Count == 0)
            {
                SetStatus("الرجاء إضافة أصناف أولاً قبل طباعة الفاتورة A4", false);
                return;
            }

            if (_pdfReportService == null)
            {
                SetStatus("خدمة طباعة PDF غير مفعلة.", false);
                return;
            }

            try
            {
                var settings = _settingsRepository.GetSettings();
                string? qrText = null;
                if (settings.EnableQrCode)
                {
                    qrText = EgyptQrHelper.GenerateSimpleInvoiceQrText(
                        InvoiceNumber,
                        DateTime.Now,
                        TotalNetRiyals,
                        settings.TaxNumber,
                        settings.PharmacyNameAr
                    );
                }

                var invoice = new Invoice
                {
                    InvoiceNumber = InvoiceNumber,
                    Date = DateTime.Now,
                    CustomerName = CustomerName,
                    CustomerPhone = CustomerPhone,
                    PaymentMethod = SelectedPaymentMethod,
                    SubtotalPiastres = SubtotalPiastres,
                    DiscountPiastres = DiscountPiastres,
                    VatPiastres = VatPiastres,
                    TotalPiastres = NetTotalPiastres,
                    PaidPiastres = Money.FromPounds(PaidRiyals).Piastres,
                    RemainingPiastres = RemainingPiastres,
                    QrCodeText = qrText
                };

                foreach (var row in CartItems)
                {
                    invoice.Items.Add(new InvoiceItem
                    {
                        ItemId = row.ItemId,
                        ItemCode = row.Code,
                        ItemNameAr = row.NameAr,
                        BatchNumber = row.BatchNumber,
                        ExpiryDate = row.ExpiryDate,
                        UnitLevel = row.SelectedUnitLevel,
                        QuantitySold = row.Quantity,
                        SmallestUnitsCount = row.SmallestUnitsToDeduct,
                        UnitPricePiastres = row.UnitPricePiastres,
                        DiscountPiastres = row.DiscountPiastres,
                        VatRatePercent = row.VatRatePercent,
                        VatPiastres = row.VatPiastres,
                        TotalPiastres = row.TotalPiastres
                    });
                }

                string pdfPath = _pdfReportService.GenerateA4InvoicePdf(invoice, settings);
                SetStatus($"تم توليد فاتورة A4 الضريبية بنجاح: {System.IO.Path.GetFileName(pdfPath)}", true);
                System.Windows.MessageBox.Show(
                    $"تم إنشاء فاتورة المبيعات الضريبية الرسمية A4 بصيغة PDF بنجاح:\n{pdfPath}",
                    "فاتورة ضريبية رسمية (A4)",
                    System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Information
                );
            }
            catch (Exception ex)
            {
                SetStatus($"فشل توليد الفاتورة A4: {ex.Message}", false);
            }
        }

        public void SuspendCurrentInvoice()
        {
            if (CartItems.Count == 0)
            {
                SetStatus("لا توجد فاتورة لتعليقها!", false);
                return;
            }
            SetStatus($"تم تعليق الفاتورة {InvoiceNumber} بنجاح (F8)", true);
            StartNewInvoice();
        }

        public void ToggleReturnMode()
        {
            CurrentInvoiceType = CurrentInvoiceType == InvoiceType.Sales ? InvoiceType.Return : InvoiceType.Sales;
            StartNewInvoice();
        }

        public void OpenDrawer()
        {
            try
            {
                var settings = _settingsRepository.GetSettings();
                if (Services.ThermalReceiptPrinter.OpenCashDrawer(settings, out string err))
                {
                    SetStatus("تم إرسال نبضة فتح درج النقدية (F10)", true);
                }
                else
                {
                    SetStatus($"تعذر فتح الدرج: {err}", false);
                }
            }
            catch (Exception ex)
            {
                SetStatus($"تعذر فتح الدرج: {ex.Message}", false);
            }
        }

        private void SetStatus(string msg, bool success)
        {
            StatusMessage = msg;
            IsStatusSuccess = success;
        }

        private static void PlayConfirmSound()
        {
            try
            {
                SystemSounds.Beep.Play();
            }
            catch { }
        }
    }
}
