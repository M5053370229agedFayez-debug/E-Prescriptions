using System;
using CommunityToolkit.Mvvm.ComponentModel;
using ePrescriptions.Core.Financial;
using ePrescriptions.Core.Helpers;
using ePrescriptions.Domain.Entities;
using ePrescriptions.Domain.Enums;

namespace ePrescriptions.App.ViewModels
{
    public class SalesItemRow : ObservableObject
    {
        public int ItemId { get; set; }
        public string Code { get; set; } = string.Empty;
        public string Barcode { get; set; } = string.Empty;
        public string NameAr { get; set; } = string.Empty;
        public string ActiveIngredient { get; set; } = string.Empty;

        public int StripsPerBox { get; set; } = 1;
        public int PiecesPerStrip { get; set; } = 10;
        public int MinStockAlertSmallestUnits { get; set; } = 30;

        public int TotalStockSmallestUnits { get; set; }

        public string BatchNumber { get; set; } = "افتراضي";
        public DateTime? ExpiryDate { get; set; }

        private UnitLevel _selectedUnitLevel = UnitLevel.Box;
        public UnitLevel SelectedUnitLevel
        {
            get => _selectedUnitLevel;
            set
            {
                if (SetProperty(ref _selectedUnitLevel, value))
                {
                    UpdatePriceBasedOnUnit();
                    Recalculate();
                }
            }
        }

        private int _quantity = 1;
        public int Quantity
        {
            get => _quantity;
            set
            {
                if (value < 1) value = 1;
                if (SetProperty(ref _quantity, value))
                {
                    Recalculate();
                }
            }
        }

        private long _unitPricePiastres;
        public long UnitPricePiastres
        {
            get => _unitPricePiastres;
            set
            {
                if (SetProperty(ref _unitPricePiastres, value))
                {
                    Recalculate();
                }
            }
        }

        private long _discountPiastres;
        public long DiscountPiastres
        {
            get => _discountPiastres;
            set
            {
                if (SetProperty(ref _discountPiastres, value))
                {
                    Recalculate();
                }
            }
        }

        /// <summary>
        /// نسبة الضريبة المطبقة على البند (0% أو 5% أو 14% أو ما حددته إعدادات الصيدلية)
        /// </summary>
        private int _vatRatePercent = 14;
        public int VatRatePercent
        {
            get => _vatRatePercent;
            set
            {
                if (SetProperty(ref _vatRatePercent, value))
                {
                    Recalculate();
                }
            }
        }

        public string VatRateDisplay => $"{VatRatePercent}%";

        private long _vatPiastres;
        public long VatPiastres
        {
            get => _vatPiastres;
            private set => SetProperty(ref _vatPiastres, value);
        }

        private long _totalPiastres;
        public long TotalPiastres
        {
            get => _totalPiastres;
            private set => SetProperty(ref _totalPiastres, value);
        }

        // إجمالي ما سيخصم من المخزون بأصغر وحدة
        public int SmallestUnitsToDeduct => UnitBreakdownHelper.CalculateSmallestUnits(SelectedUnitLevel, Quantity, StripsPerBox, PiecesPerStrip);

        // تنبيه قرب النفاد
        public bool IsLowStock => TotalStockSmallestUnits <= MinStockAlertSmallestUnits;

        public string FormattedStockDisplay => UnitBreakdownHelper.FormatStockDetailed(TotalStockSmallestUnits, StripsPerBox, PiecesPerStrip);

        public string FormattedUnitPrice => Money.FromPiastres(UnitPricePiastres).ToFormattedString();
        public string FormattedVat => Money.FromPiastres(VatPiastres).ToFormattedString();
        public string FormattedTotal => Money.FromPiastres(TotalPiastres).ToFormattedString();
        public string FormattedExpiry => ExpiryDate.HasValue ? ExpiryDate.Value.ToString("yyyy-MM-dd") : "-";

        private readonly Item _originalItem;
        private readonly PriceCategory _currentCategory;

        public SalesItemRow(Item item, PriceCategory category, int defaultVatPercent = 14)
        {
            _originalItem = item;
            _currentCategory = category;

            ItemId = item.Id;
            Code = item.Code;
            Barcode = item.Barcode;
            NameAr = item.NameAr;
            ActiveIngredient = item.ActiveIngredient;
            StripsPerBox = item.StripsPerBox;
            PiecesPerStrip = item.PiecesPerStrip;
            MinStockAlertSmallestUnits = item.MinStockAlertSmallestUnits;
            TotalStockSmallestUnits = item.TotalStockSmallestUnits;
            VatRatePercent = item.GetEffectiveVatRate(defaultVatPercent);

            if (item.Batches != null && item.Batches.Count > 0)
            {
                BatchNumber = item.Batches[0].BatchNumber;
                ExpiryDate = item.Batches[0].ExpiryDate;
            }

            UpdatePriceBasedOnUnit();
            Recalculate();
        }

        public void UpdatePriceBasedOnUnit()
        {
            _unitPricePiastres = _originalItem.GetPriceForUnit(SelectedUnitLevel, _currentCategory);
            OnPropertyChanged(nameof(UnitPricePiastres));
            OnPropertyChanged(nameof(FormattedUnitPrice));
        }

        public void Recalculate()
        {
            long grossSubtotal = UnitPricePiastres * Quantity;
            long taxableAmount = Math.Max(0, grossSubtotal - DiscountPiastres);

            // حساب الضريبة بنسبة البند المحددة مع تقريب Half-Up بالقروش
            VatPiastres = Money.CalculateVat(taxableAmount, VatRatePercent).Piastres;
            TotalPiastres = taxableAmount + VatPiastres;

            OnPropertyChanged(nameof(SmallestUnitsToDeduct));
            OnPropertyChanged(nameof(FormattedUnitPrice));
            OnPropertyChanged(nameof(FormattedVat));
            OnPropertyChanged(nameof(FormattedTotal));
            OnPropertyChanged(nameof(VatRateDisplay));
        }
    }
}
