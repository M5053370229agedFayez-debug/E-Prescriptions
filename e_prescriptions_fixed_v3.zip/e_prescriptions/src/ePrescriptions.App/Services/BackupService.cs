using System;
using System.Data.SQLite;
using System.IO;
using ePrescriptions.Core.Helpers;
using ePrescriptions.Data;

namespace ePrescriptions.App.Services
{
    public interface IBackupService
    {
        string GetDefaultBackupFolder();
        bool CreateBackup(string? customFolder, out string backupFilePath, out string errorMessage);
        bool RestoreBackup(string backupFilePath, out string errorMessage);
        bool ValidateBackupFile(string backupFilePath, out string errorMessage);
    }

    public class BackupService : IBackupService
    {
        private readonly DatabaseContext _dbContext;

        public BackupService(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public string GetDefaultBackupFolder()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string backupDir = Path.Combine(appData, "e_prescriptions", "backups");
            if (!Directory.Exists(backupDir))
            {
                Directory.CreateDirectory(backupDir);
            }
            return backupDir;
        }

        public bool CreateBackup(string? customFolder, out string backupFilePath, out string errorMessage)
        {
            errorMessage = string.Empty;
            backupFilePath = string.Empty;

            try
            {
                string folder = string.IsNullOrWhiteSpace(customFolder) ? GetDefaultBackupFolder() : customFolder;
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                // 1) عمل Checkpoint كامل لملف WAL لضمان دمج كافة العمليات المعلقة
                using (var conn = _dbContext.CreateConnection())
                {
                    using var cmd = conn.CreateCommand();
                    cmd.CommandText = "PRAGMA wal_checkpoint(FULL);";
                    cmd.ExecuteNonQuery();
                }

                string timeStamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string fileName = $"e_prescriptions_backup_{timeStamp}.db";
                backupFilePath = Path.Combine(folder, fileName);

                // 2) نسخ ملف قاعدة البيانات الأصلي
                File.Copy(_dbContext.DatabasePath, backupFilePath, overwrite: true);

                Logger.LogInfo($"تم إنشاء نسخة احتياطية بنجاح في: {backupFilePath}", "BackupService.CreateBackup");
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                Logger.LogException(ex, "BackupService.CreateBackup");
                return false;
            }
        }

        public bool ValidateBackupFile(string backupFilePath, out string errorMessage)
        {
            errorMessage = string.Empty;
            if (!File.Exists(backupFilePath))
            {
                errorMessage = "ملف النسخة الاحتياطية غير موجود.";
                return false;
            }

            try
            {
                var connStr = $"Data Source={backupFilePath};Version=3;Read Only=True;";
                using var conn = new SQLiteConnection(connStr);
                conn.Open();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "PRAGMA integrity_check;";
                var result = cmd.ExecuteScalar()?.ToString();

                if (string.Equals(result, "ok", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
                else
                {
                    errorMessage = $"فشل فحص سلامة قاعدة البيانات: {result}";
                    return false;
                }
            }
            catch (Exception ex)
            {
                errorMessage = $"الملف غير صالح أو تالف: {ex.Message}";
                return false;
            }
        }

        public bool RestoreBackup(string backupFilePath, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (!ValidateBackupFile(backupFilePath, out errorMessage))
            {
                return false;
            }

            try
            {
                // إغلاق أي اتصالات معلقة عبر تفريغ الـ Pool
                SQLiteConnection.ClearAllPools();

                // أخذ نسخة احتياطية سريعة من الملف الحالي كإجراء وقائي قبل الاستبدال
                string emergencyBackup = _dbContext.DatabasePath + ".pre_restore.bak";
                File.Copy(_dbContext.DatabasePath, emergencyBackup, overwrite: true);

                // استبدال ملف قاعدة البيانات الحالي
                File.Copy(backupFilePath, _dbContext.DatabasePath, overwrite: true);

                // حذف ملفات WAL و SHM المؤقتة إن وجدت لضمان تطابق رأس الملف
                string walFile = _dbContext.DatabasePath + "-wal";
                string shmFile = _dbContext.DatabasePath + "-shm";
                if (File.Exists(walFile)) File.Delete(walFile);
                if (File.Exists(shmFile)) File.Delete(shmFile);

                Logger.LogInfo($"تم استعادة قاعدة البيانات بنجاح من: {backupFilePath}", "BackupService.RestoreBackup");
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                Logger.LogException(ex, "BackupService.RestoreBackup");
                return false;
            }
        }
    }
}
