using System;
using System.Collections.Generic;
using System.Data.SQLite;
using ePrescriptions.Core.Helpers;
using ePrescriptions.Domain.Entities;
using ePrescriptions.Domain.Enums;

namespace ePrescriptions.Data.Repositories
{
    public class InvoiceRepository
    {
        private readonly DatabaseContext _dbContext;
        private readonly ItemRepository _itemRepository;

        public InvoiceRepository(DatabaseContext dbContext, ItemRepository itemRepository)
        {
            _dbContext = dbContext;
            _itemRepository = itemRepository;
        }

        public string GenerateNextInvoiceNumber(InvoiceType type)
        {
            string prefix = type == InvoiceType.Sales ? "INV" : "RET";
            string year = DateTime.Now.Year.ToString();

            using var conn = _dbContext.CreateConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM Invoices WHERE Type = @type;";
            cmd.Parameters.AddWithValue("@type", (int)type);
            long count = Convert.ToInt64(cmd.ExecuteScalar() ?? 0) + 1;

            return $"{prefix}-{year}-{count:D5}";
        }

        private static bool TableHasColumn(SQLiteConnection conn, string table, string column)
        {
            try
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = $"PRAGMA table_info({table});";
                using var r = cmd.ExecuteReader();
                while (r.Read())
                {
                    if (string.Equals(r["name"]?.ToString(), column, StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// حفظ الفاتورة وبنودها وخصم المخزون بنظام FEFO وتحديث حساب العميل والوردية داخل Transaction واحدة محكمة
        /// </summary>
        public bool SaveInvoice(Invoice invoice, out string errorMessage)
        {
            errorMessage = string.Empty;
            using var conn = _dbContext.CreateConnection();
            using var trans = conn.BeginTransaction();

            try
            {
                bool usePiastres = TableHasColumn(conn, "Invoices", "SubtotalPiastres");
                string subCol = usePiastres ? "SubtotalPiastres" : "SubtotalPiastres";
                string discCol = usePiastres ? "DiscountPiastres" : "DiscountPiastres";
                string vatCol = usePiastres ? "VatPiastres" : "VatPiastres";
                string totalCol = usePiastres ? "TotalPiastres" : "TotalPiastres";
                string paidCol = usePiastres ? "PaidPiastres" : "PaidPiastres";
                string remCol = usePiastres ? "RemainingPiastres" : "RemainingPiastres";
                string qrCol = TableHasColumn(conn, "Invoices", "QrCodeText") ? "QrCodeText" : "ZatcaQrBase64";

                // 1) حفظ رأس الفاتورة
                using var insertInvoiceCmd = conn.CreateCommand();
                insertInvoiceCmd.Transaction = trans;
                insertInvoiceCmd.CommandText = $@"
                    INSERT INTO Invoices (
                        InvoiceNumber, Type, Date, CustomerId, CustomerName, CustomerPhone,
                        PriceCategory, PaymentMethod, PrescriptionNumber, DoctorName,
                        UserId, UserName, ShiftId, {subCol}, {discCol},
                        {vatCol}, {totalCol}, {paidCol}, {remCol}, Notes, {qrCol}
                    ) VALUES (
                        @num, @type, @date, @cId, @cName, @cPhone,
                        @pCat, @pMethod, @rxNum, @docName,
                        @uId, @uName, @sId, @sub, @disc,
                        @vat, @total, @paid, @rem, @notes, @qr
                    );
                    SELECT last_insert_rowid();";

                insertInvoiceCmd.Parameters.AddWithValue("@num", invoice.InvoiceNumber);
                insertInvoiceCmd.Parameters.AddWithValue("@type", (int)invoice.Type);
                insertInvoiceCmd.Parameters.AddWithValue("@date", invoice.Date.ToString("yyyy-MM-dd HH:mm:ss"));
                insertInvoiceCmd.Parameters.AddWithValue("@cId", (object?)invoice.CustomerId ?? DBNull.Value);
                insertInvoiceCmd.Parameters.AddWithValue("@cName", invoice.CustomerName);
                insertInvoiceCmd.Parameters.AddWithValue("@cPhone", invoice.CustomerPhone ?? string.Empty);
                insertInvoiceCmd.Parameters.AddWithValue("@pCat", (int)invoice.PriceCategory);
                insertInvoiceCmd.Parameters.AddWithValue("@pMethod", (int)invoice.PaymentMethod);
                insertInvoiceCmd.Parameters.AddWithValue("@rxNum", (object?)invoice.PrescriptionNumber ?? DBNull.Value);
                insertInvoiceCmd.Parameters.AddWithValue("@docName", (object?)invoice.DoctorName ?? DBNull.Value);
                insertInvoiceCmd.Parameters.AddWithValue("@uId", invoice.UserId);
                insertInvoiceCmd.Parameters.AddWithValue("@uName", invoice.UserName);
                insertInvoiceCmd.Parameters.AddWithValue("@sId", invoice.ShiftId);
                insertInvoiceCmd.Parameters.AddWithValue("@sub", invoice.SubtotalPiastres);
                insertInvoiceCmd.Parameters.AddWithValue("@disc", invoice.DiscountPiastres);
                insertInvoiceCmd.Parameters.AddWithValue("@vat", invoice.VatPiastres);
                insertInvoiceCmd.Parameters.AddWithValue("@total", invoice.TotalPiastres);
                insertInvoiceCmd.Parameters.AddWithValue("@paid", invoice.PaidPiastres);
                insertInvoiceCmd.Parameters.AddWithValue("@rem", invoice.RemainingPiastres);
                insertInvoiceCmd.Parameters.AddWithValue("@notes", (object?)invoice.Notes ?? DBNull.Value);
                insertInvoiceCmd.Parameters.AddWithValue("@qr", (object?)invoice.QrCodeText ?? DBNull.Value);

                int invoiceId = Convert.ToInt32(insertInvoiceCmd.ExecuteScalar());
                invoice.Id = invoiceId;

                bool itemUsePiastres = TableHasColumn(conn, "InvoiceItems", "UnitPricePiastres");
                string itmPriceCol = itemUsePiastres ? "UnitPricePiastres" : "UnitPricePiastres";
                string itmDiscCol = itemUsePiastres ? "DiscountPiastres" : "DiscountPiastres";
                string itmVatCol = itemUsePiastres ? "VatPiastres" : "VatPiastres";
                string itmTotCol = itemUsePiastres ? "TotalPiastres" : "TotalPiastres";

                // 2) حفظ بنود الفاتورة وخصم المخزون بنظام FEFO
                foreach (var item in invoice.Items)
                {
                    item.InvoiceId = invoiceId;

                    string batchUsed = item.BatchNumber;
                    DateTime? expUsed = item.ExpiryDate;

                    if (invoice.Type == InvoiceType.Sales)
                    {
                        // خصم من المخزون بنظام FEFO
                        _itemRepository.DeductStockFefo(item.ItemId, item.SmallestUnitsCount, conn, trans, out batchUsed, out expUsed);
                        item.BatchNumber = batchUsed;
                        item.ExpiryDate = expUsed;
                    }
                    else
                    {
                        // مرتجع مبيعات: إعادة الكمية إلى المخزون
                        _itemRepository.RestoreStock(item.ItemId, item.SmallestUnitsCount, item.BatchNumber, conn, trans);
                    }

                    using var insertItemCmd = conn.CreateCommand();
                    insertItemCmd.Transaction = trans;
                    insertItemCmd.CommandText = $@"
                        INSERT INTO InvoiceItems (
                            InvoiceId, ItemId, ItemCode, ItemNameAr, BatchNumber, ExpiryDate,
                            UnitLevel, QuantitySold, SmallestUnitsCount, {itmPriceCol},
                            {itmDiscCol}, VatRatePercent, {itmVatCol}, {itmTotCol}
                        ) VALUES (
                            @invId, @itemId, @code, @name, @batch, @exp,
                            @uLevel, @qty, @smUnits, @price,
                            @disc, @vatRate, @vat, @total
                        );";

                    insertItemCmd.Parameters.AddWithValue("@invId", invoiceId);
                    insertItemCmd.Parameters.AddWithValue("@itemId", item.ItemId);
                    insertItemCmd.Parameters.AddWithValue("@code", item.ItemCode);
                    insertItemCmd.Parameters.AddWithValue("@name", item.ItemNameAr);
                    insertItemCmd.Parameters.AddWithValue("@batch", item.BatchNumber);
                    insertItemCmd.Parameters.AddWithValue("@exp", item.ExpiryDate?.ToString("yyyy-MM-dd") ?? string.Empty);
                    insertItemCmd.Parameters.AddWithValue("@uLevel", (int)item.UnitLevel);
                    insertItemCmd.Parameters.AddWithValue("@qty", item.QuantitySold);
                    insertItemCmd.Parameters.AddWithValue("@smUnits", item.SmallestUnitsCount);
                    insertItemCmd.Parameters.AddWithValue("@price", item.UnitPricePiastres);
                    insertItemCmd.Parameters.AddWithValue("@disc", item.DiscountPiastres);
                    insertItemCmd.Parameters.AddWithValue("@vatRate", item.VatRatePercent);
                    insertItemCmd.Parameters.AddWithValue("@vat", item.VatPiastres);
                    insertItemCmd.Parameters.AddWithValue("@total", item.TotalPiastres);
                    insertItemCmd.ExecuteNonQuery();
                }

                // 3) تحديث رصيد العميل: البيع الآجل يزيد المديونية، ومرتجع الآجل يخفضها
                if (invoice.CustomerId.HasValue && invoice.CustomerId.Value > 1 && invoice.RemainingPiastres > 0)
                {
                    long delta = invoice.Type == InvoiceType.Return ? -invoice.RemainingPiastres : invoice.RemainingPiastres;

                    using var updateCustomerCmd = conn.CreateCommand();
                    updateCustomerCmd.Transaction = trans;
                    updateCustomerCmd.CommandText = @"
                        UPDATE Customers
                        SET CurrentBalancePiastres = CurrentBalancePiastres + @delta
                        WHERE Id = @cId;";
                    updateCustomerCmd.Parameters.AddWithValue("@delta", delta);
                    updateCustomerCmd.Parameters.AddWithValue("@cId", invoice.CustomerId.Value);
                    updateCustomerCmd.ExecuteNonQuery();
                }

                // 4) تحديث مجاميع الوردية الحالية
                if (invoice.ShiftId > 0)
                {
                    using var updateShiftCmd = conn.CreateCommand();
                    updateShiftCmd.Transaction = trans;

                    if (invoice.Type == InvoiceType.Return)
                    {
                        // المرتجع النقدي يخرج من الدرج ولا يُحسب ضمن المبيعات
                        updateShiftCmd.CommandText = @"
                            UPDATE Shifts
                            SET TotalReturnsCashPiastres = TotalReturnsCashPiastres + (CASE WHEN @pMethod = 1 THEN @amt ELSE 0 END),
                                ExpectedCashPiastres = ExpectedCashPiastres - (CASE WHEN @pMethod = 1 THEN @amt ELSE 0 END)
                            WHERE Id = @sId;";
                    }
                    else
                    {
                        string columnToUpdate = invoice.PaymentMethod switch
                        {
                            PaymentMethod.Cash => "TotalSalesCashPiastres",
                            PaymentMethod.Network => "TotalSalesNetworkPiastres",
                            PaymentMethod.OnAccount => "TotalSalesOnAccountPiastres",
                            _ => "TotalSalesCashPiastres"
                        };

                        updateShiftCmd.CommandText = $@"
                            UPDATE Shifts
                            SET {columnToUpdate} = {columnToUpdate} + @amt,
                                ExpectedCashPiastres = ExpectedCashPiastres + (CASE WHEN @pMethod = 1 THEN @amt ELSE 0 END)
                            WHERE Id = @sId;";
                    }

                    updateShiftCmd.Parameters.AddWithValue("@amt", invoice.TotalPiastres);
                    updateShiftCmd.Parameters.AddWithValue("@pMethod", (int)invoice.PaymentMethod);
                    updateShiftCmd.Parameters.AddWithValue("@sId", invoice.ShiftId);
                    updateShiftCmd.ExecuteNonQuery();
                }

                trans.Commit();
                return true;
            }
            catch (Exception ex)
            {
                trans.Rollback();
                errorMessage = ex.Message;
                Logger.LogException(ex, "SaveInvoice");
                return false;
            }
        }

        public void SaveSuspendedInvoice(SuspendedInvoice suspended)
        {
            using var conn = _dbContext.CreateConnection();
            bool usePiastres = TableHasColumn(conn, "SuspendedInvoices", "TotalPiastres");
            string totCol = usePiastres ? "TotalPiastres" : "TotalPiastres";

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
                INSERT OR REPLACE INTO SuspendedInvoices (ReferenceCode, SuspendedAt, CustomerName, JsonData, {totCol})
                VALUES (@ref, @date, @cust, @json, @tot);";
            cmd.Parameters.AddWithValue("@ref", suspended.ReferenceCode);
            cmd.Parameters.AddWithValue("@date", suspended.SuspendedAt.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.Parameters.AddWithValue("@cust", suspended.CustomerName);
            cmd.Parameters.AddWithValue("@json", suspended.JsonData);
            cmd.Parameters.AddWithValue("@tot", suspended.TotalPiastres);
            cmd.ExecuteNonQuery();
        }

        public List<SuspendedInvoice> GetSuspendedInvoices()
        {
            var list = new List<SuspendedInvoice>();
            using var conn = _dbContext.CreateConnection();
            bool usePiastres = TableHasColumn(conn, "SuspendedInvoices", "TotalPiastres");
            string totCol = usePiastres ? "TotalPiastres" : "TotalPiastres";

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT Id, ReferenceCode, SuspendedAt, CustomerName, JsonData, {totCol} FROM SuspendedInvoices ORDER BY SuspendedAt DESC;";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new SuspendedInvoice
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    ReferenceCode = reader["ReferenceCode"].ToString() ?? string.Empty,
                    SuspendedAt = DateTime.Parse(reader["SuspendedAt"].ToString() ?? DateTime.Now.ToString("s")),
                    CustomerName = reader["CustomerName"].ToString() ?? string.Empty,
                    JsonData = reader["JsonData"].ToString() ?? string.Empty,
                    TotalPiastres = Convert.ToInt64(reader[totCol])
                });
            }
            return list;
        }

        public void DeleteSuspendedInvoice(int id)
        {
            using var conn = _dbContext.CreateConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM SuspendedInvoices WHERE Id = @id;";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }
    }
}
