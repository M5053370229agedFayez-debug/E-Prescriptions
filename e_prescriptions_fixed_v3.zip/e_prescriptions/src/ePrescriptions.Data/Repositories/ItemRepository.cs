using System;
using System.Collections.Generic;
using System.Data.SQLite;
using ePrescriptions.Domain.Entities;

namespace ePrescriptions.Data.Repositories
{
    public class ItemRepository
    {
        private readonly DatabaseContext _dbContext;

        public ItemRepository(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// بحث فوري بالاسم العربي، الإنجليزي، المادة الفعالة، الكود، أو الباركود
        /// </summary>
        public List<Item> Search(string query, int limit = 50)
        {
            var list = new List<Item>();
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();

            string pattern = $"%{query.Trim()}%";
            cmd.CommandText = @"
                SELECT Id, Code, Barcode, NameAr, NameEn, ActiveIngredient,
                       StripsPerBox, PiecesPerStrip, RetailPriceBoxPiastres,
                       WholesalePriceBoxPiastres, CostPriceBoxPiastres,
                       MinStockAlertSmallestUnits, IsPrescriptionRequired,
                       IsVatExempt, CustomVatPercent, TotalStockSmallestUnits, IsActive
                FROM Items
                WHERE IsActive = 1 AND (
                    NameAr LIKE @q OR
                    NameEn LIKE @q OR
                    ActiveIngredient LIKE @q OR
                    Code LIKE @q OR
                    Barcode LIKE @q
                )
                ORDER BY NameAr ASC
                LIMIT @limit;";

            cmd.Parameters.AddWithValue("@q", pattern);
            cmd.Parameters.AddWithValue("@limit", limit);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(MapItem(reader));
            }

            return list;
        }

        public Item? GetByBarcodeOrCode(string code)
        {
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT Id, Code, Barcode, NameAr, NameEn, ActiveIngredient,
                       StripsPerBox, PiecesPerStrip, RetailPriceBoxPiastres,
                       WholesalePriceBoxPiastres, CostPriceBoxPiastres,
                       MinStockAlertSmallestUnits, IsPrescriptionRequired,
                       IsVatExempt, CustomVatPercent, TotalStockSmallestUnits, IsActive
                FROM Items
                WHERE IsActive = 1 AND (Barcode = @c OR Code = @c)
                LIMIT 1;";
            cmd.Parameters.AddWithValue("@c", code.Trim());

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                var item = MapItem(reader);
                item.Batches = GetActiveBatches(item.Id, conn);
                return item;
            }

            return null;
        }

        public Item? GetById(int id)
        {
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT Id, Code, Barcode, NameAr, NameEn, ActiveIngredient,
                       StripsPerBox, PiecesPerStrip, RetailPriceBoxPiastres,
                       WholesalePriceBoxPiastres, CostPriceBoxPiastres,
                       MinStockAlertSmallestUnits, IsPrescriptionRequired,
                       IsVatExempt, CustomVatPercent, TotalStockSmallestUnits, IsActive
                FROM Items
                WHERE Id = @id
                LIMIT 1;";
            cmd.Parameters.AddWithValue("@id", id);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                var item = MapItem(reader);
                item.Batches = GetActiveBatches(item.Id, conn);
                return item;
            }

            return null;
        }

        public List<Item> GetTopSellingItems(int limit = 10)
        {
            var list = new List<Item>();
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT i.Id, i.Code, i.Barcode, i.NameAr, i.NameEn, i.ActiveIngredient,
                       i.StripsPerBox, i.PiecesPerStrip, i.RetailPriceBoxPiastres,
                       i.WholesalePriceBoxPiastres, i.CostPriceBoxPiastres,
                       i.MinStockAlertSmallestUnits, i.IsPrescriptionRequired,
                       i.IsVatExempt, i.CustomVatPercent, i.TotalStockSmallestUnits, i.IsActive,
                       IFNULL(SUM(it.SmallestUnitsCount), 0) AS SoldUnits
                FROM Items i
                LEFT JOIN InvoiceItems it ON i.Id = it.ItemId
                WHERE i.IsActive = 1
                GROUP BY i.Id
                ORDER BY SoldUnits DESC, i.NameAr ASC
                LIMIT @limit;";
            cmd.Parameters.AddWithValue("@limit", limit);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var item = MapItem(reader);
                item.Batches = GetActiveBatches(item.Id, conn);
                list.Add(item);
            }

            return list;
        }

        public List<ItemBatch> GetActiveBatches(int itemId, SQLiteConnection? existingConn = null, SQLiteTransaction? existingTrans = null)
        {
            var batches = new List<ItemBatch>();
            bool closeConn = false;
            var conn = existingConn;
            if (conn == null)
            {
                conn = _dbContext.CreateConnection();
                closeConn = true;
            }

            try
            {
                using var cmd = conn.CreateCommand();
                if (existingTrans != null)
                {
                    cmd.Transaction = existingTrans;
                }
                cmd.CommandText = @"
                    SELECT Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits,
                           CostPricePerSmallestUnitPiastres, CreatedAt
                    FROM ItemBatches
                    WHERE ItemId = @itemId AND RemainingSmallestUnits > 0
                    ORDER BY date(ExpiryDate) ASC;";
                cmd.Parameters.AddWithValue("@itemId", itemId);

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    batches.Add(new ItemBatch
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        ItemId = Convert.ToInt32(reader["ItemId"]),
                        BatchNumber = reader["BatchNumber"]?.ToString() ?? string.Empty,
                        ExpiryDate = DateTime.Parse(reader["ExpiryDate"]?.ToString() ?? DateTime.Today.ToString("yyyy-MM-dd")),
                        RemainingSmallestUnits = Convert.ToInt32(reader["RemainingSmallestUnits"]),
                        CostPricePerSmallestUnitPiastres = Convert.ToInt64(reader["CostPricePerSmallestUnitPiastres"]),
                        CreatedAt = DateTime.Parse(reader["CreatedAt"]?.ToString() ?? DateTime.Now.ToString("s"))
                    });
                }
            }
            finally
            {
                if (closeConn)
                {
                    conn.Dispose();
                }
            }

            return batches;
        }

        /// <summary>
        /// خصم المخزون بنظام FEFO (الأقرب صلاحية أولاً) داخل Transaction موحدة
        /// </summary>
        public void DeductStockFefo(int itemId, int unitsToDeduct, SQLiteConnection conn, SQLiteTransaction trans, out string batchNumberUsed, out DateTime? expiryDateUsed)
        {
            batchNumberUsed = "عام";
            expiryDateUsed = null;

            if (unitsToDeduct <= 0) return;

            var batches = GetActiveBatches(itemId, conn, trans);
            int remainingToDeduct = unitsToDeduct;

            foreach (var batch in batches)
            {
                if (remainingToDeduct <= 0) break;

                int deductFromThis = Math.Min(batch.RemainingSmallestUnits, remainingToDeduct);
                batch.RemainingSmallestUnits -= deductFromThis;
                remainingToDeduct -= deductFromThis;

                batchNumberUsed = batch.BatchNumber;
                expiryDateUsed = batch.ExpiryDate;

                using var updateBatchCmd = conn.CreateCommand();
                updateBatchCmd.Transaction = trans;
                updateBatchCmd.CommandText = @"
                    UPDATE ItemBatches
                    SET RemainingSmallestUnits = @rem
                    WHERE Id = @bId;";
                updateBatchCmd.Parameters.AddWithValue("@rem", batch.RemainingSmallestUnits);
                updateBatchCmd.Parameters.AddWithValue("@bId", batch.Id);
                updateBatchCmd.ExecuteNonQuery();
            }

            // تحديث إجمالي مخزون الصنف
            using var updateItemCmd = conn.CreateCommand();
            updateItemCmd.Transaction = trans;
            updateItemCmd.CommandText = @"
                UPDATE Items
                SET TotalStockSmallestUnits = TotalStockSmallestUnits - @deduct
                WHERE Id = @itemId;";
            updateItemCmd.Parameters.AddWithValue("@deduct", unitsToDeduct);
            updateItemCmd.Parameters.AddWithValue("@itemId", itemId);
            updateItemCmd.ExecuteNonQuery();
        }

        /// <summary>
        /// إرجاع كمية إلى المخزون عند مرتجع المبيعات (إلى نفس التشغيلة إن وُجدت) داخل Transaction موحدة
        /// </summary>
        public void RestoreStock(int itemId, int unitsToRestore, string? batchNumber, SQLiteConnection conn, SQLiteTransaction trans)
        {
            if (unitsToRestore <= 0) return;

            if (!string.IsNullOrWhiteSpace(batchNumber))
            {
                using var batchCmd = conn.CreateCommand();
                batchCmd.Transaction = trans;
                batchCmd.CommandText = @"
                    UPDATE ItemBatches
                    SET RemainingSmallestUnits = RemainingSmallestUnits + @u
                    WHERE Id = (
                        SELECT Id FROM ItemBatches
                        WHERE ItemId = @itemId AND BatchNumber = @b
                        ORDER BY date(ExpiryDate) DESC LIMIT 1
                    );";
                batchCmd.Parameters.AddWithValue("@u", unitsToRestore);
                batchCmd.Parameters.AddWithValue("@itemId", itemId);
                batchCmd.Parameters.AddWithValue("@b", batchNumber);
                batchCmd.ExecuteNonQuery();
            }

            using var itemCmd = conn.CreateCommand();
            itemCmd.Transaction = trans;
            itemCmd.CommandText = @"
                UPDATE Items
                SET TotalStockSmallestUnits = TotalStockSmallestUnits + @u
                WHERE Id = @itemId;";
            itemCmd.Parameters.AddWithValue("@u", unitsToRestore);
            itemCmd.Parameters.AddWithValue("@itemId", itemId);
            itemCmd.ExecuteNonQuery();
        }

        public List<Item> GetAllItems()
        {
            var list = new List<Item>();
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT Id, Code, Barcode, NameAr, NameEn, ActiveIngredient,
                       StripsPerBox, PiecesPerStrip, RetailPriceBoxPiastres,
                       WholesalePriceBoxPiastres, CostPriceBoxPiastres,
                       MinStockAlertSmallestUnits, IsPrescriptionRequired,
                       IsVatExempt, CustomVatPercent, TotalStockSmallestUnits, IsActive
                FROM Items
                WHERE IsActive = 1
                ORDER BY NameAr ASC;";

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(MapItem(reader));
            }
            return list;
        }

        public int SaveItem(Item item)
        {
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();

            if (item.Id == 0)
            {
                cmd.CommandText = @"
                    INSERT INTO Items (
                        Code, Barcode, NameAr, NameEn, ActiveIngredient,
                        StripsPerBox, PiecesPerStrip, RetailPriceBoxPiastres,
                        WholesalePriceBoxPiastres, CostPriceBoxPiastres,
                        MinStockAlertSmallestUnits, IsPrescriptionRequired,
                        IsVatExempt, CustomVatPercent, TotalStockSmallestUnits, IsActive
                    ) VALUES (
                        @code, @barcode, @nameAr, @nameEn, @ingr,
                        @strips, @pieces, @retPrice, @wsPrice, @costPrice,
                        @minAlert, @rxReq, @vatExempt, @custVat, @stock, 1
                    );
                    SELECT last_insert_rowid();";
            }
            else
            {
                cmd.CommandText = @"
                    UPDATE Items SET
                        Code = @code,
                        Barcode = @barcode,
                        NameAr = @nameAr,
                        NameEn = @nameEn,
                        ActiveIngredient = @ingr,
                        StripsPerBox = @strips,
                        PiecesPerStrip = @pieces,
                        RetailPriceBoxPiastres = @retPrice,
                        WholesalePriceBoxPiastres = @wsPrice,
                        CostPriceBoxPiastres = @costPrice,
                        MinStockAlertSmallestUnits = @minAlert,
                        IsPrescriptionRequired = @rxReq,
                        IsVatExempt = @vatExempt,
                        CustomVatPercent = @custVat
                    WHERE Id = @id;";
                cmd.Parameters.AddWithValue("@id", item.Id);
            }

            cmd.Parameters.AddWithValue("@code", item.Code.Trim());
            cmd.Parameters.AddWithValue("@barcode", item.Barcode.Trim());
            cmd.Parameters.AddWithValue("@nameAr", item.NameAr.Trim());
            cmd.Parameters.AddWithValue("@nameEn", item.NameEn.Trim());
            cmd.Parameters.AddWithValue("@ingr", item.ActiveIngredient.Trim());
            cmd.Parameters.AddWithValue("@strips", item.StripsPerBox);
            cmd.Parameters.AddWithValue("@pieces", item.PiecesPerStrip);
            cmd.Parameters.AddWithValue("@retPrice", item.RetailPriceBoxPiastres);
            cmd.Parameters.AddWithValue("@wsPrice", item.WholesalePriceBoxPiastres);
            cmd.Parameters.AddWithValue("@costPrice", item.CostPriceBoxPiastres);
            cmd.Parameters.AddWithValue("@minAlert", item.MinStockAlertSmallestUnits);
            cmd.Parameters.AddWithValue("@rxReq", item.IsPrescriptionRequired ? 1 : 0);
            cmd.Parameters.AddWithValue("@vatExempt", item.IsVatExempt ? 1 : 0);
            cmd.Parameters.AddWithValue("@custVat", item.CustomVatPercent);
            cmd.Parameters.AddWithValue("@stock", item.TotalStockSmallestUnits);

            if (item.Id == 0)
            {
                item.Id = Convert.ToInt32(cmd.ExecuteScalar());
            }
            else
            {
                cmd.ExecuteNonQuery();
            }

            return item.Id;
        }

        public void AddBatch(int itemId, string batchNumber, DateTime expiryDate, int smallestUnits, long costPricePerBoxPiastres)
        {
            var item = GetById(itemId);
            int perBox = item?.SmallestUnitsPerBox ?? 1;
            AddBatch(new ItemBatch
            {
                ItemId = itemId,
                BatchNumber = batchNumber.Trim(),
                ExpiryDate = expiryDate,
                RemainingSmallestUnits = smallestUnits,
                CostPricePerSmallestUnitPiastres = (costPricePerBoxPiastres + (perBox / 2)) / Math.Max(1, perBox)
            });
        }

        public void AddBatch(ItemBatch batch)
        {
            using var conn = _dbContext.CreateConnection();
            using var trans = conn.BeginTransaction();
            try
            {
                using var cmd = conn.CreateCommand();
                cmd.Transaction = trans;
                cmd.CommandText = @"
                    INSERT INTO ItemBatches (
                        ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits,
                        CostPricePerSmallestUnitPiastres, CreatedAt
                    ) VALUES (
                        @itemId, @batch, @exp, @rem, @cost, @created
                    );
                    SELECT last_insert_rowid();";
                cmd.Parameters.AddWithValue("@itemId", batch.ItemId);
                cmd.Parameters.AddWithValue("@batch", batch.BatchNumber);
                cmd.Parameters.AddWithValue("@exp", batch.ExpiryDate.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@rem", batch.RemainingSmallestUnits);
                cmd.Parameters.AddWithValue("@cost", batch.CostPricePerSmallestUnitPiastres);
                cmd.Parameters.AddWithValue("@created", DateTime.Now.ToString("s"));

                batch.Id = Convert.ToInt32(cmd.ExecuteScalar());

                // تحديث رصيد الصنف
                using var updateCmd = conn.CreateCommand();
                updateCmd.Transaction = trans;
                updateCmd.CommandText = @"
                    UPDATE Items
                    SET TotalStockSmallestUnits = TotalStockSmallestUnits + @added
                    WHERE Id = @itemId;";
                updateCmd.Parameters.AddWithValue("@added", batch.RemainingSmallestUnits);
                updateCmd.Parameters.AddWithValue("@itemId", batch.ItemId);
                updateCmd.ExecuteNonQuery();

                trans.Commit();
            }
            catch
            {
                trans.Rollback();
                throw;
            }
        }

        /// <summary>
        /// التشغيلات المنتهية أو القريبة من الانتهاء (خلال withinDays يوماً) مع بيانات الصنف
        /// </summary>
        public List<(Item Item, ItemBatch Batch)> GetNearExpiryBatches(int withinDays = 90)
        {
            var list = new List<(Item, ItemBatch)>();
            using var conn = _dbContext.CreateConnection();
            using var cmd = conn.CreateCommand();

            string thresholdDate = DateTime.Today.AddDays(withinDays).ToString("yyyy-MM-dd");
            cmd.CommandText = @"
                SELECT b.Id AS BId, b.ItemId, b.BatchNumber, b.ExpiryDate, b.RemainingSmallestUnits,
                       b.CostPricePerSmallestUnitPiastres, b.CreatedAt,
                       i.Id, i.Code, i.Barcode, i.NameAr, i.NameEn, i.ActiveIngredient,
                       i.StripsPerBox, i.PiecesPerStrip, i.RetailPriceBoxPiastres,
                       i.WholesalePriceBoxPiastres, i.CostPriceBoxPiastres,
                       i.MinStockAlertSmallestUnits, i.IsPrescriptionRequired,
                       i.IsVatExempt, i.CustomVatPercent, i.TotalStockSmallestUnits, i.IsActive
                FROM ItemBatches b
                JOIN Items i ON b.ItemId = i.Id
                WHERE i.IsActive = 1
                  AND b.RemainingSmallestUnits > 0
                  AND date(b.ExpiryDate) <= date(@thresh)
                ORDER BY date(b.ExpiryDate) ASC;";
            cmd.Parameters.AddWithValue("@thresh", thresholdDate);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var item = MapItem(reader);
                var batch = new ItemBatch
                {
                    Id = Convert.ToInt32(reader["BId"]),
                    ItemId = Convert.ToInt32(reader["ItemId"]),
                    BatchNumber = reader["BatchNumber"]?.ToString() ?? string.Empty,
                    ExpiryDate = DateTime.Parse(reader["ExpiryDate"]?.ToString() ?? DateTime.Today.ToString("yyyy-MM-dd")),
                    RemainingSmallestUnits = Convert.ToInt32(reader["RemainingSmallestUnits"]),
                    CostPricePerSmallestUnitPiastres = Convert.ToInt64(reader["CostPricePerSmallestUnitPiastres"]),
                    CreatedAt = DateTime.Parse(reader["CreatedAt"]?.ToString() ?? DateTime.Now.ToString("s"))
                };
                list.Add((item, batch));
            }

            return list;
        }

        public List<Item> GetLowStockItems()
        {
            var list = new List<Item>();
            using var conn = _dbContext.CreateConnection();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT Id, Code, Barcode, NameAr, NameEn, ActiveIngredient,
                       StripsPerBox, PiecesPerStrip, RetailPriceBoxPiastres,
                       WholesalePriceBoxPiastres, CostPriceBoxPiastres,
                       MinStockAlertSmallestUnits, IsPrescriptionRequired,
                       IsVatExempt, CustomVatPercent, TotalStockSmallestUnits, IsActive
                FROM Items
                WHERE IsActive = 1 AND TotalStockSmallestUnits <= MinStockAlertSmallestUnits
                ORDER BY TotalStockSmallestUnits ASC;";

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(MapItem(reader));
            }

            return list;
        }

        public void RecordStockAdjustment(Domain.Entities.StockAdjustment adj)
        {
            using var conn = _dbContext.CreateConnection();
            using var trans = conn.BeginTransaction();
            try
            {
                using var cmd = conn.CreateCommand();
                cmd.Transaction = trans;
                cmd.CommandText = @"
                    INSERT INTO StockAdjustments (
                        AdjustmentNumber, ItemId, ItemCode, ItemNameAr, Date,
                        BookSmallestUnits, ActualSmallestUnits, DifferenceSmallestUnits,
                        Reason, CreatedAt
                    ) VALUES (
                        @num, @itemId, @code, @name, @date,
                        @book, @actual, @diff,
                        @reason, datetime('now')
                    );";
                cmd.Parameters.AddWithValue("@num", adj.AdjustmentNumber);
                cmd.Parameters.AddWithValue("@itemId", adj.ItemId);
                cmd.Parameters.AddWithValue("@code", adj.ItemCode);
                cmd.Parameters.AddWithValue("@name", adj.ItemNameAr);
                cmd.Parameters.AddWithValue("@date", adj.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@book", adj.BookSmallestUnits);
                cmd.Parameters.AddWithValue("@actual", adj.ActualSmallestUnits);
                cmd.Parameters.AddWithValue("@diff", adj.DifferenceSmallestUnits);
                cmd.Parameters.AddWithValue("@reason", adj.Reason);
                cmd.ExecuteNonQuery();

                // تحديث رصيد الصنف ليتطابق مع الفعلي
                using var updateCmd = conn.CreateCommand();
                updateCmd.Transaction = trans;
                updateCmd.CommandText = @"
                    UPDATE Items
                    SET TotalStockSmallestUnits = @actual
                    WHERE Id = @itemId;";
                updateCmd.Parameters.AddWithValue("@actual", adj.ActualSmallestUnits);
                updateCmd.Parameters.AddWithValue("@itemId", adj.ItemId);
                updateCmd.ExecuteNonQuery();

                trans.Commit();
            }
            catch
            {
                trans.Rollback();
                throw;
            }
        }

        private static Item MapItem(SQLiteDataReader reader)
        {
            int customVat = -1;
            try
            {
                object val = reader["CustomVatPercent"];
                if (val != null && val != DBNull.Value)
                    customVat = Convert.ToInt32(val);
            }
            catch { }

            return new Item
            {
                Id = Convert.ToInt32(reader["Id"]),
                Code = reader["Code"]?.ToString() ?? string.Empty,
                Barcode = reader["Barcode"]?.ToString() ?? string.Empty,
                NameAr = reader["NameAr"]?.ToString() ?? string.Empty,
                NameEn = reader["NameEn"]?.ToString() ?? string.Empty,
                ActiveIngredient = reader["ActiveIngredient"]?.ToString() ?? string.Empty,
                StripsPerBox = Convert.ToInt32(reader["StripsPerBox"]),
                PiecesPerStrip = Convert.ToInt32(reader["PiecesPerStrip"]),
                RetailPriceBoxPiastres = Convert.ToInt64(reader["RetailPriceBoxPiastres"]),
                WholesalePriceBoxPiastres = Convert.ToInt64(reader["WholesalePriceBoxPiastres"]),
                CostPriceBoxPiastres = Convert.ToInt64(reader["CostPriceBoxPiastres"]),
                MinStockAlertSmallestUnits = Convert.ToInt32(reader["MinStockAlertSmallestUnits"]),
                IsPrescriptionRequired = Convert.ToInt32(reader["IsPrescriptionRequired"]) == 1,
                IsVatExempt = Convert.ToInt32(reader["IsVatExempt"]) == 1,
                CustomVatPercent = customVat,
                TotalStockSmallestUnits = Convert.ToInt32(reader["TotalStockSmallestUnits"]),
                IsActive = Convert.ToInt32(reader["IsActive"]) == 1
            };
        }
    }
}
