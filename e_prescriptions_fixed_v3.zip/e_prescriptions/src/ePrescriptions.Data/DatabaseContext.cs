using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Reflection;
using ePrescriptions.Core.Helpers;
using ePrescriptions.Core.Security;

namespace ePrescriptions.Data
{
    /// <summary>
    /// مدير قاعدة بيانات SQLite: يتولى المسار في AppData، تفعيل WAL والمفاتيح الأجنبية،
    /// وتطبيق الـ Migrations الآمنة عبر PRAGMA user_version.
    /// </summary>
    public class DatabaseContext
    {
        /// <summary>
        /// آخر إصدار للمخطط (عدد ملفات الـ Migrations المطبقة)
        /// </summary>
        public const int LatestSchemaVersion = 6;

        private readonly string _connectionString;
        private readonly bool _isInMemory;

        /// <summary>
        /// المسار الفعلي لملف قاعدة البيانات (ملف مؤقت في وضع :memory:)
        /// </summary>
        public string DatabasePath { get; }

        public static string DefaultDatabaseDirectory => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "e_prescriptions"
        );

        public static string DefaultDatabasePath => Path.Combine(DefaultDatabaseDirectory, "e_prescriptions.db");

        public DatabaseContext(string? customDbPath = null)
        {
            if (customDbPath == ":memory:" || customDbPath == "Data Source=:memory:")
            {
                // SQLite تنشئ قاعدة :memory: مستقلة وفارغة لكل اتصال جديد، والمستودعات هنا تفتح اتصالاً لكل عملية،
                // لذلك نستخدم ملفاً مؤقتاً فريداً يعمل كقاعدة "مؤقتة" مشتركة بين كل الاتصالات ويُحذف عند إنهاء العملية.
                _isInMemory = true;
                string tempPath = Path.Combine(Path.GetTempPath(), "e_prescriptions_tmp_" + Guid.NewGuid().ToString("N") + ".db");
                DatabasePath = tempPath;
                _connectionString = $"Data Source={tempPath};Version=3;Pooling=False;";
                AppDomain.CurrentDomain.ProcessExit += (_, __) =>
                {
                    try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { /* تجاهل */ }
                };
            }
            else
            {
                _isInMemory = false;
                string dbPath = customDbPath ?? DefaultDatabasePath;
                DatabasePath = dbPath;
                string directory = Path.GetDirectoryName(dbPath)!;
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                _connectionString = $"Data Source={dbPath};Version=3;Pooling=True;Max Pool Size=10;";
            }
        }

        /// <summary>
        /// فتح اتصال SQLite مع تفعيل WAL والمفاتيح الأجنبية
        /// </summary>
        public SQLiteConnection CreateConnection()
        {
            var conn = new SQLiteConnection(_connectionString);
            conn.Open();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = "PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;";
            if (!_isInMemory)
            {
                cmd.CommandText += " PRAGMA journal_mode = WAL;";
            }
            cmd.ExecuteNonQuery();

            return conn;
        }

        /// <summary>
        /// فحص وتطبيق التحديثات المرقّمة (Migrations) عبر PRAGMA user_version داخل Transaction
        /// </summary>
        public void InitializeAndMigrate(bool seedData = true)
        {
            using var conn = CreateConnection();
            using var trans = conn.BeginTransaction();
            try
            {
                int currentVersion = GetUserVersion(conn);
                Logger.LogInfo($"فحص إصدار قاعدة البيانات: {currentVersion}", "DatabaseContext");

                if (currentVersion < 1)
                {
                    // تطبيق Migration 001: الهيكل الأساسي
                    string script001 = ReadEmbeddedSql("001_InitialSchema.sql");
                    ExecuteSqlScript(conn, script001);
                    SetUserVersion(conn, 1);
                    Logger.LogInfo("تم تطبيق Migration 001 بنجاح.", "DatabaseContext");
                }

                if (currentVersion < 2 && seedData)
                {
                    // تطبيق Migration 002: البيانات الأولية
                    string script002 = ReadEmbeddedSql("002_SeedData.sql");
                    ExecuteSqlScript(conn, script002);
                    SetUserVersion(conn, 2);
                    Logger.LogInfo("تم تطبيق Migration 002 بنجاح.", "DatabaseContext");
                }

                if (currentVersion < 3)
                {
                    // تطبيق Migration 003: المشتريات والسندات والجرد
                    string script003 = ReadEmbeddedSql("003_PurchasesAndVouchers.sql");
                    ExecuteSqlScript(conn, script003);
                    SetUserVersion(conn, 3);
                    Logger.LogInfo("تم تطبيق Migration 003 بنجاح.", "DatabaseContext");
                }

                if (currentVersion < 4)
                {
                    // تطبيق Migration 004: المصروفات والقيود اليومية والمالية
                    string script004 = ReadEmbeddedSql("004_FinanceAndStaff.sql");
                    ExecuteSqlScript(conn, script004);
                    SetUserVersion(conn, 4);
                    Logger.LogInfo("تم تطبيق Migration 004 بنجاح.", "DatabaseContext");
                }

                if (currentVersion < 5)
                {
                    // تطبيق Migration 005: التوطين المصري وضبط نسب الضريبة وبيانات الصيدلية
                    string script005 = ReadEmbeddedSql("005_EgyptLocalization.sql");
                    ExecuteSqlScript(conn, script005);
                    SetUserVersion(conn, 5);
                    Logger.LogInfo("تم تطبيق Migration 005 بنجاح.", "DatabaseContext");
                }

                if (currentVersion < 6)
                {
                    // تطبيق Migration 006: جدول سجل نشاط صاحب الصيدلية
                    string script006 = ReadEmbeddedSql("006_OwnerAuditLog.sql");
                    ExecuteSqlScript(conn, script006);
                    SetUserVersion(conn, 6);
                    Logger.LogInfo("تم تطبيق Migration 006 بنجاح.", "DatabaseContext");
                }

                trans.Commit();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                Logger.LogException(ex, "InitializeAndMigrate");
                throw;
            }

            if (seedData)
            {
                EnsureOwnerAccountExists();
            }
        }

        /// <summary>
        /// إنشاء حساب صاحب الصيدلية تلقائياً إن لم يكن موجوداً (مرة واحدة فقط).
        /// الحساب لا يظهر في أي شاشة لإدارة المستخدمين (UserRepository.GetAll يستثنيه دائماً)،
        /// ولا توجد قائمة مستخدمين في شاشة الدخول؛ يُدخل عبر اسم المستخدم وكلمة المرور مباشرة فقط.
        /// بيانات الدخول الافتراضية: pharmacy_owner / ChangeMe@Owner1 — يجب تغييرها فوراً بعد أول دخول.
        /// </summary>
        private void EnsureOwnerAccountExists()
        {
            using var conn = CreateConnection();
            using var checkCmd = conn.CreateCommand();
            checkCmd.CommandText = "SELECT COUNT(*) FROM Users WHERE Role = 99;";
            long existing = Convert.ToInt64(checkCmd.ExecuteScalar() ?? 0);
            if (existing > 0) return;

            string hash = PasswordHasher.HashPassword("ChangeMe@Owner1");

            using var insertCmd = conn.CreateCommand();
            insertCmd.CommandText = @"
                INSERT INTO Users (Username, FullName, PasswordHash, Role, IsActive, CreatedAt)
                VALUES (@u, @f, @h, 99, 1, @c);";
            insertCmd.Parameters.AddWithValue("@u", "pharmacy_owner");
            insertCmd.Parameters.AddWithValue("@f", "صاحب الصيدلية");
            insertCmd.Parameters.AddWithValue("@h", hash);
            insertCmd.Parameters.AddWithValue("@c", DateTime.Now.ToString("s"));
            insertCmd.ExecuteNonQuery();

            Logger.LogInfo("تم إنشاء حساب صاحب الصيدلية الافتراضي. يجب تغيير كلمة المرور فوراً.", "DatabaseContext.EnsureOwnerAccountExists");
        }

        public static int GetUserVersion(SQLiteConnection conn)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "PRAGMA user_version;";
            object? result = cmd.ExecuteScalar();
            return result != null ? Convert.ToInt32(result) : 0;
        }

        private static void SetUserVersion(SQLiteConnection conn, int version)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"PRAGMA user_version = {version};";
            cmd.ExecuteNonQuery();
        }

        private static void ExecuteSqlScript(SQLiteConnection conn, string script)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = script;
            cmd.ExecuteNonQuery();
        }

        private static string ReadEmbeddedSql(string filename)
        {
            var assembly = Assembly.GetExecutingAssembly();
            // البحث عن المورد المدمج بغض النظر عن الـ namespace prefix
            string? resourceName = null;
            foreach (var name in assembly.GetManifestResourceNames())
            {
                if (name.EndsWith(filename, StringComparison.OrdinalIgnoreCase))
                {
                    resourceName = name;
                    break;
                }
            }

            if (resourceName == null)
            {
                // محاولة قراءة الملف مباشرة من مسار التطبيق إذا لم يكن مدمجاً
                string localPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Migrations", filename);
                if (File.Exists(localPath))
                {
                    return File.ReadAllText(localPath);
                }
                throw new FileNotFoundException($"تعذر العثور على ملف السكربت المدمج: {filename}");
            }

            using var stream = assembly.GetManifestResourceStream(resourceName)!;
            using var reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }
    }
}
