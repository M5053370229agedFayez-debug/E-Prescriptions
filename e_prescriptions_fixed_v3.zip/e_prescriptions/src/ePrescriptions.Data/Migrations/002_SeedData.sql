-- 002_SeedData.sql: البيانات الأولية والتجريبية لصيدلية e_prescriptions

-- كلمة مرور المسؤول الافتراضية هي admin123 مشفرة بـ PBKDF2 (50000 تكرار مع salt عشوائي)
INSERT OR IGNORE INTO Users (Id, Username, FullName, PasswordHash, Role, IsActive, CreatedAt)
VALUES (1, 'admin', 'ماجد القبانى (مدير النظام)', '50000:6p3kM1w8Yq2vL9zP4rT0wQ==:VqO/k6Q3dY+d3mN7H5F9l8pQ2rS1tU0vW9xY8zB7cD4=', 1, 1, datetime('now'));

INSERT OR IGNORE INTO Users (Id, Username, FullName, PasswordHash, Role, IsActive, CreatedAt)
VALUES (2, 'pharmacist', 'سارة الأحمد (صيدلاني)', '50000:6p3kM1w8Yq2vL9zP4rT0wQ==:VqO/k6Q3dY+d3mN7H5F9l8pQ2rS1tU0vW9xY8zB7cD4=', 2, 1, datetime('now'));

-- الإعدادات الأولية للصيدلية
INSERT OR REPLACE INTO PharmacySettings (
    Id, PharmacyNameAr, PharmacyNameEn, TaxNumber, CommercialRegister, LicenseNumber, Phone, Address, DefaultVatPercent
) VALUES (
    1, 'صيدلية النخبة الطبية', 'Elite Pharmacy Care', '300987654300003', '1010776655', 'LIC-2024-889', '0114567890', 'صيدلية ماجد القبانى', 15
);

-- عميل نقدي افتراضي
INSERT OR IGNORE INTO Customers (Id, Name, Phone, CreditLimitHalalas, CurrentBalanceHalalas, PriceCategory, Notes, IsActive)
VALUES (1, 'عميل نقدي', '0500000000', 0, 0, 1, 'العميل النقدي العام', 1);

INSERT OR IGNORE INTO Customers (Id, Name, Phone, CreditLimitHalalas, CurrentBalanceHalalas, PriceCategory, Notes, IsActive)
VALUES (2, 'مجمع النخبة الطبي (آجل)', '0551122334', 500000, 0, 2, 'حساب آجل بحد ائتماني 5000 جنيه', 1);

-- مورد افتراضي
INSERT OR IGNORE INTO Suppliers (Id, Name, Phone, TaxNumber, Address, BalanceHalalas, IsActive)
VALUES (1, 'شركة الدواء للخدمات الطبية', '0138999999', '300011223300003', 'الدمام - المدينة الصناعية', 0, 1);

-- عينات أدوية واقعية مع معاملات التجزئة والأسعار بالهللات
-- 1) بنادول إكسترا: علبة بها 2 شريط، كل شريط 12 قرص = 24 قرص
-- سعر العلبة: 12.00 جنيه (1200 قرش)
INSERT OR IGNORE INTO Items (Id, Code, Barcode, NameAr, NameEn, ActiveIngredient, StripsPerBox, PiecesPerStrip, RetailPriceBoxHalalas, WholesalePriceBoxHalalas, CostPriceBoxHalalas, MinStockAlertSmallestUnits, TotalStockSmallestUnits, IsActive)
VALUES (1, 'MED-001', '6281001000101', 'بنادول إكسترا أحمر 24 قرص', 'Panadol Extra 24 Tabs', 'Paracetamol 500mg + Caffeine 65mg', 2, 12, 1200, 1050, 900, 48, 240, 1);

INSERT OR IGNORE INTO ItemBatches (Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits, CostPricePerSmallestUnitHalalas, CreatedAt)
VALUES (1, 1, 'BN-2024-A1', date('now', '+18 months'), 240, 38, datetime('now'));

-- 2) أوجمنتين 1 جم: علبة بها 2 شريط، كل شريط 7 أقراص = 14 قرص
-- سعر العلبة: 56.50 جنيه (5650 قرش)
INSERT OR IGNORE INTO Items (Id, Code, Barcode, NameAr, NameEn, ActiveIngredient, StripsPerBox, PiecesPerStrip, RetailPriceBoxHalalas, WholesalePriceBoxHalalas, CostPriceBoxHalalas, MinStockAlertSmallestUnits, TotalStockSmallestUnits, IsActive)
VALUES (2, 'MED-002', '6281001000202', 'أوجمنتين 1 جم 14 قرص', 'Augmentin 1g 14 Tabs', 'Amoxicillin + Clavulanic Acid', 2, 7, 5650, 5000, 4200, 28, 140, 1);

INSERT OR IGNORE INTO ItemBatches (Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits, CostPricePerSmallestUnitHalalas, CreatedAt)
VALUES (2, 2, 'BN-2024-AUG', date('now', '+14 months'), 140, 300, datetime('now'));

-- 3) كونكور 5 مجم: علبة بها 3 أشرطة، كل شريط 10 أقراص = 30 قرص
-- سعر العلبة: 24.80 جنيه (2480 قرش)
INSERT OR IGNORE INTO Items (Id, Code, Barcode, NameAr, NameEn, ActiveIngredient, StripsPerBox, PiecesPerStrip, RetailPriceBoxHalalas, WholesalePriceBoxHalalas, CostPriceBoxHalalas, MinStockAlertSmallestUnits, TotalStockSmallestUnits, IsActive)
VALUES (3, 'MED-003', '6281001000303', 'كونكور 5 مجم 30 قرص', 'Concor 5mg 30 Tabs', 'Bisoprolol Fumarate 5mg', 3, 10, 2480, 2200, 1850, 30, 180, 1);

INSERT OR IGNORE INTO ItemBatches (Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits, CostPricePerSmallestUnitHalalas, CreatedAt)
VALUES (3, 3, 'BN-2024-CNC', date('now', '+24 months'), 180, 62, datetime('now'));

-- 4) نكسيوم 40 مجم: علبة بها 2 شريط، كل شريط 14 قرص = 28 قرص
-- سعر العلبة: 88.00 جنيه (8800 قرش)
INSERT OR IGNORE INTO Items (Id, Code, Barcode, NameAr, NameEn, ActiveIngredient, StripsPerBox, PiecesPerStrip, RetailPriceBoxHalalas, WholesalePriceBoxHalalas, CostPriceBoxHalalas, MinStockAlertSmallestUnits, TotalStockSmallestUnits, IsActive)
VALUES (4, 'MED-004', '6281001000404', 'نكسيوم 40 مجم 28 قرص', 'Nexium 40mg 28 Tabs', 'Esomeprazole 40mg', 2, 14, 8800, 8000, 6800, 28, 112, 1);

INSERT OR IGNORE INTO ItemBatches (Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits, CostPricePerSmallestUnitHalalas, CreatedAt)
VALUES (4, 4, 'BN-2024-NX4', date('now', '+10 months'), 112, 243, datetime('now'));

-- 5) كتافلام 50 مجم: علبة بها 2 شريط، كل شريط 10 أقراص = 20 قرص
-- دفعة قريبة الصلاحية لاختبار تنبيهات FEFO
INSERT OR IGNORE INTO Items (Id, Code, Barcode, NameAr, NameEn, ActiveIngredient, StripsPerBox, PiecesPerStrip, RetailPriceBoxHalalas, WholesalePriceBoxHalalas, CostPriceBoxHalalas, MinStockAlertSmallestUnits, TotalStockSmallestUnits, IsActive)
VALUES (5, 'MED-005', '6281001000505', 'كتافلام 50 مجم 20 قرص', 'Cataflam 50mg 20 Tabs', 'Diclofenac Potassium 50mg', 2, 10, 2150, 1900, 1600, 20, 80, 1);

INSERT OR IGNORE INTO ItemBatches (Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits, CostPricePerSmallestUnitHalalas, CreatedAt)
VALUES (5, 5, 'BN-2024-CTF-NEAR', date('now', '+45 days'), 40, 80, datetime('now'));

INSERT OR IGNORE INTO ItemBatches (Id, ItemId, BatchNumber, ExpiryDate, RemainingSmallestUnits, CostPricePerSmallestUnitHalalas, CreatedAt)
VALUES (6, 5, 'BN-2024-CTF-FAR', date('now', '+16 months'), 40, 80, datetime('now'));
