using System;
using System.Threading;

namespace ePrescriptions.Core.Helpers
{
    /// <summary>
    /// قفل النسخة الواحدة للبرنامج باستخدام Mutex لمنع تشغيل نسختين في وقت واحد والتعارض على ملف SQLite.
    /// </summary>
    public sealed class SingleInstanceMutex : IDisposable
    {
        private readonly Mutex _mutex;
        private readonly bool _hasHandle;
        private bool _disposed;

        public bool IsSingleInstance => _hasHandle;

        public SingleInstanceMutex(string appUniqueId = "Global\\e_prescriptions_SingleInstance_App_Mutex")
        {
            _mutex = new Mutex(true, appUniqueId, out _hasHandle);
        }

        public void Dispose()
        {
            if (_disposed) return;
            if (_hasHandle)
            {
                try
                {
                    _mutex.ReleaseMutex();
                }
                catch (ObjectDisposedException) { }
            }
            _mutex.Dispose();
            _disposed = true;
        }
    }
}
