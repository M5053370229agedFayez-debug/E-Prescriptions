# تعديلات المراجعة الآلية (قبل أول بناء)

1. استبدال كل Halalas بـ Piastres وFromRiyals/ToRiyals بـ FromPounds/ToPounds في كل ملفات C# وXAML. كانت الكيانات وMoney وmigration 005 قد تغيّرت بينما بقيت نحو 600 إشارة قديمة في المستودعات والـ ViewModels والاختبارات.
2. إضافة src/ePrescriptions.App/Resources/app.ico وbeep.wav (كانا مذكورين في App.csproj وغير موجودين).
3. حذف tests/.../ZatcaQrTests.cs (يشير إلى ZatcaQrHelper المحذوف) وإضافة EgyptQrTests.cs.
4. مشروع الاختبارات: إضافة مرجع إلى ePrescriptions.App وتفعيل UseWPF (لأن ReportingAndExportTests وSessionAndLabelTests تستخدمان ePrescriptions.App).

لم يتم بناء المشروع (لا يوجد مترجم .NET Framework في بيئة المراجعة). تم فقط: تشغيل migrations 001 إلى 005 على SQLite بنجاح، والتحقق أن كل أعمدة Piastres في استعلامات SQL موجودة في المخطط النهائي، وأن كل StaticResource في XAML معرَّف، وأن تسجيلات DI تطابق الخدمات.

متبقٍ كتسمية فقط: خصائص مثل PaidRiyals وTotalNetRiyals في SalesViewModel (قيمتها بالجنيه، والـ Bindings في XAML متطابقة معها).

---

# مراجعة ثانية (ترجمة فعلية لـ Core/Domain/Data + ViewModels/Services بمكتبات بديلة)

## أخطاء ترجمة
1. نقل `UnitBreakdownHelper.cs` من Core إلى Domain (Core لا يرى Domain). الـ namespace بقي `ePrescriptions.Core.Helpers`.
2. إضافة `StatementRow` (كانت مستخدمة ولا تعريف لها).
3. `ZatcaQrBase64` → `QrCodeText` في SalesViewModel وPdfReportService وThermalReceiptPrinter.
4. إضافة `DatabaseContext.DatabasePath` (يستخدمها BackupService).
5. إضافة `RawPrinterHelper.SendBytesToPrinter(..., out string)`.
6. `XBrushes.DarkIndigo` → `XBrushes.Indigo`.
7. `SalesViewModel`: `Core.Printing.ThermalReceiptPrinter` → `Services.ThermalReceiptPrinter`.
8. إضافة `StatusMessage` إلى ReportsViewModel وSettingsViewModel.
9. SettingsViewModel: استدعاءات PrintTestTicket/OpenCashDrawer بدون `out`.
10. InventoryViewModel: GetNearExpiryBatches ترجع (Item, ItemBatch)، وتحميل AddBatch(itemId, ...)، وإزالة الكتابة على DifferenceSmallestUnits (للقراءة فقط).
11. ExcelExportService: شرط يخلط decimal/double.
12. مراجع إطار صريحة (System.Drawing وSystem.Data) في ملفات csproj.

## أخطاء منطقية
- `DatabaseContext(":memory:")` كان ينشئ قاعدة فارغة مع كل اتصال (يستخدم الآن ملفاً مؤقتاً يُحذف عند الخروج).
- مرتجعات المبيعات: ترجع المخزون، وتخصم من درج الوردية، وتخفض رصيد العميل الآجل.
- SalesViewModel: المستخدم والوردية من جلسة الدخول (كانت 1 ثابتة)، وربط الفاتورة بعميل مسجل (للبيع الآجل).
- حفظ صنف معدّل لا يصفّر سعر الجملة وإعدادات الضريبة.
- حفظ الإعدادات لا يعيد ضبط EnableQrCode وTaxNumberLength، والصيدلي المسؤول يُحفظ في العمود الذي يُقرأ منه (ResponsiblePharmacist).
- App.xaml.cs: ثقافة ar-EG (ar-SA كانت تكتب التواريخ بالسنة الهجرية في قاعدة البيانات)، ومنع إغلاق البرنامج بعد شاشة الدخول.
- إزالة ALTER TABLE المتكرر مع كل بحث.
- اختبار الـ migrations يتوقع الإصدار الأخير (5) بدل 2، وإضافة SalesAndReturnsTests.

## ما لم يُتحقق منه
XAML وApp.xaml.cs وملفات code-behind لم تُترجم (WPF غير متاح)، وPdfSharp/ClosedXML/QRCoder استُبدلت ببدائل تقريبية. اختبارات xUnit الأصلية لم تُشغَّل بل شُغّلت بمشغّل مكافئ (27 ناجحاً).

---

# ميزة "صاحب الصيدلية" (دور مخفي بصلاحيات تفوق المدير)

## الفكرة
- دور جديد `UserRole.Owner` فوق `Admin`، لا يظهر في أي شاشة إدارة مستخدمين أو قائمة اختيار، ولا توجد قائمة مستخدمين في شاشة الدخول أصلاً (تسجيل الدخول بيانات حرة فقط).
- أي تعديل يقوم به صاحب الصيدلية (حالياً: تعديل بيانات صنف، تعديل سعر، تسوية جرد/كمية) يُسجَّل في جدول `OwnerAuditLog` منفصل، تاريخه وقيمته قبل/بعد — لكن هذا السجل لا يظهر إلا في شاشة "سجل نشاطي"، وهذه الشاشة لا تظهر في الشريط الجانبي إلا لحساب Owner (`IsOwner` في `MainViewModel`).
- تعديلات المدير والموظفين العاديين تبقى كما هي تماماً، من غير أي تسجيل إضافي (حسب الطلب).

## حساب صاحب الصيدلية الافتراضي
يُنشأ تلقائياً أول مرة تُشغَّل فيها قاعدة البيانات (`DatabaseContext.EnsureOwnerAccountExists`):
- **اسم المستخدم:** `pharmacy_owner`
- **كلمة المرور الافتراضية:** `ChangeMe@Owner1`

**يجب تغيير كلمة المرور فوراً بعد أول تشغيل.** لا توجد شاشة حالياً لتغيير كلمة مرور صاحب الصيدلية بنفسه من داخل البرنامج؛ أقرب طريقة آمنة هي تعديلها مباشرة في قاعدة البيانات (hash) أو إضافة شاشة "تغيير كلمة المرور" لاحقاً - هذا غير منفَّذ بعد.

## التعديلات بالتفصيل
1. `UserRole.Owner = 99` في `DomainEnums.cs`.
2. Migration 006: جدول `OwnerAuditLog` (الحقل، القيمة قبل/بعد، التاريخ).
3. `UserRepository.GetAll(includeOwner = false)`: يستثني Owner افتراضياً من كل الشاشات.
4. `UserRepository.SaveStaffUser(...)`: الدالة الفعلية لإنشاء/تعديل موظف (كانت `StaffViewModel.AddUser` شكلية ومفيهاش حفظ حقيقي - اتصلحت). ترفض صراحة أي محاولة لإنشاء أو تعديل حساب بدور Owner، حتى لو حاول حد يمرر Role=Owner يدوياً أو يعدّل على ID بتاع صاحب الصيدلية.
5. `OwnerAuditLogRepository`: تسجيل وقراءة السجل. `LogChange` بيتجاهل الاستدعاء لو القيمة قبل وبعد متطابقة (مفيش تسجيل فاضي).
6. `InventoryViewModel`: عند حفظ تعديل صنف أو تسوية جرد، لو المستخدم الحالي (`IUserSessionService.CurrentUser`) دوره Owner، بيسجل كل حقل اتغير. أي دور تاني (Admin/Pharmacist/Cashier) بيعدي عادي من غير أي تسجيل.
7. `MainViewModel.IsOwner` + زر "سجل نشاطي" في الشريط الجانبي، مربوط بـ `Visibility` عن طريق `BooleanToVisibilityConverter`، ومش ظاهر إلا لو `IsOwner == true`.
8. `OwnerLogViewModel` + `OwnerLogView`: شاشة عرض السجل، مسجلة في DI كـ Transient، مفيش أي شاشة تانية بتعرضها أو تلمّح لوجودها.

## اختبارات جديدة (OwnerHiddenAccountTests.cs - 7 اختبارات، كلها ناجحة)
- حساب Owner واحد بس بيتعمل تلقائياً أول تشغيل.
- `GetAll()` الافتراضية ما بترجعش حساب Owner أبداً.
- تسجيل الدخول بحساب Owner شغال رغم إنه مخفي من القوائم.
- `SaveStaffUser` بترفض إنشاء أو تعديل أي حساب بدور Owner (برسالة InvalidOperationException).
- سجل التدقيق بيسجل ويرجع آخر التعديلات بالترتيب الصحيح (الأحدث أولاً)، وبيتجاهل التعديلات اللي مفيهاش تغيير فعلي.

## نطاق التطبيق الحالي (مهم)
التسجيل مُفعّل فعلياً على تعديلات الأصناف وتسوية الجرد بس (`InventoryViewModel`)، لأنه ده المثال اللي اتطلب بالظبط (تعديل كمية/بيانات صنف). الشاشات التانية (العملاء، الموردين، المشتريات، المالية، الفواتير، الإعدادات) ما اتوصلتش بنفس الآلية لسه. لو حابب تغطية أشمل، نفس النمط (`LogOwnerEditIfApplicable`) قابل للتكرار بسهولة في أي ViewModel تاني بيحفظ تعديل.

## نقاط لازم تاخدها في الاعتبار
- مفيش شاشة لتغيير كلمة مرور صاحب الصيدلية من داخل البرنامج حالياً — كلمة المرور الافتراضية معروفة في هذا الملف، فلازم تتغير فوراً.
- `MainViewModel.CurrentUserDisplay` الافتراضي (قبل تسجيل الدخول) لسه بيظهر اسم "ماجد القبانى (مدير النظام)" — ده نص افتراضي موجود من قبل، مش له علاقة بحساب Owner.
- لم يتم التحقق من XAML عبر WPF حقيقي (مفيش WPF في بيئة الفحص)، لكن تم التأكد من صحة XML لكل ملفات .xaml وتجميع منطق ViewModels/Services بمترجم C# حقيقي من غير أخطاء.
